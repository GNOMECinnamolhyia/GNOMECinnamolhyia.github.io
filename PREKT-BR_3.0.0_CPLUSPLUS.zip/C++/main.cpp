// PrekT-BR — Navegador personal basado en WebKitGTK 6
// Versión 2.1 - SECURE ENHANCED (C++ / gtkmm-4.0 port)
//
// Compilar:
//   g++ -std=c++20 main.cpp -o prektbr \
//       $(pkg-config --cflags --libs gtk4 webkitgtk-6.0 glib-2.0 gio-2.0) \
//       -lcrypto
//
// Dependencias: gtkmm-4.0, webkitgtk-6.0, libssl-dev

#include <gtk/gtk.h>
#include <webkit/webkit.h>
#include <glib.h>
#include <gio/gio.h>

#include <openssl/evp.h>
#include <openssl/rand.h>

#include <string>
#include <vector>
#include <functional>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <cassert>
#include <memory>
#include <cstring>

// ─── nlohmann/json (header-only, incluir aparte o usar submodule) ──────────
// Si no tienes nlohmann instalado: sudo apt install nlohmann-json3-dev
#include <nlohmann/json.hpp>
using json = nlohmann::json;

// ─── Base64 (usamos GLib) ──────────────────────────────────────────────────

static std::string base64_encode(const std::vector<uint8_t>& data) {
    gchar* enc = g_base64_encode(data.data(), data.size());
    std::string result(enc);
    g_free(enc);
    return result;
}

static std::vector<uint8_t> base64_decode(const std::string& s) {
    gsize out_len = 0;
    guchar* dec = g_base64_decode(s.c_str(), &out_len);
    std::vector<uint8_t> result(dec, dec + out_len);
    g_free(dec);
    return result;
}

// ─── Rutas de datos ────────────────────────────────────────────────────────

static std::string dataDir() {
    return std::string(g_get_home_dir()) + "/.local/share/prektbr";
}
static std::string historyFile()   { return dataDir() + "/history.json";   }
static std::string bookmarksFile() { return dataDir() + "/bookmarks.json"; }
static std::string saltFile()      { return dataDir() + "/.salt";          }

// ─── Cifrado XOR + PBKDF2 ─────────────────────────────────────────────────

static std::vector<uint8_t> getOrCreateSalt() {
    std::ifstream f(saltFile(), std::ios::binary);
    if (f) {
        std::vector<uint8_t> salt(32);
        f.read(reinterpret_cast<char*>(salt.data()), 32);
        if (f.gcount() == 32) return salt;
    }
    std::vector<uint8_t> salt(32);
    RAND_bytes(salt.data(), 32);
    std::ofstream of(saltFile(), std::ios::binary);
    of.write(reinterpret_cast<const char*>(salt.data()), 32);
    return salt;
}

static std::vector<uint8_t> g_masterKey;

static void initMasterKey() {
    const char* user = g_get_user_name();
    std::string password = std::string(user ? user : "prektbr") + "prektbr-v3";
    auto salt = getOrCreateSalt();

    g_masterKey.resize(64);
    PKCS5_PBKDF2_HMAC(
        password.c_str(), (int)password.size(),
        salt.data(), (int)salt.size(),
        200000,
        EVP_sha256(),
        (int)g_masterKey.size(),
        g_masterKey.data()
    );
}

static std::vector<uint8_t> xorBytes(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(data.size());
    size_t klen = g_masterKey.size();
    for (size_t i = 0; i < data.size(); i++)
        out[i] = data[i] ^ g_masterKey[i % klen];
    return out;
}

static json loadJson(const std::string& path, const json& def) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return def;
    std::string raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    // Intentar descifrar
    try {
        auto decoded = base64_decode(raw);
        auto plain   = xorBytes(decoded);
        return json::parse(plain.begin(), plain.end());
    } catch (...) {
        try { return json::parse(raw); } catch (...) {}
    }
    return def;
}

static void saveJson(const std::string& path, const json& data) {
    try {
        std::string s   = data.dump(2);
        std::vector<uint8_t> raw(s.begin(), s.end());
        auto ciphered    = xorBytes(raw);
        std::string b64  = base64_encode(ciphered);
        std::ofstream f(path, std::ios::binary);
        f.write(b64.c_str(), b64.size());
    } catch (const std::exception& e) {
        g_warning("[prektbr] Error guardando %s: %s", path.c_str(), e.what());
    }
}

// ─── CSS global ────────────────────────────────────────────────────────────

static const char* GLOBAL_CSS = R"CSS(
.toolbar { background-color: #1e1e2e; border-bottom: 1px solid #313244; padding: 4px 8px; }
.url-entry { background-color: #313244; color: #cdd6f4; border: 1px solid #45475a;
    border-radius: 6px; padding: 4px 10px; font-size: 14px; min-height: 32px; }
.url-entry:focus { border-color: #89b4fa; background-color: #1e1e2e; }
.nav-button { background-color: transparent; color: #cdd6f4; border: none;
    border-radius: 6px; padding: 4px 8px; min-width: 32px; min-height: 32px; font-size: 16px; }
.nav-button:hover { background-color: #313244; }
.nav-button:disabled { color: #45475a; }
.tabbar { background-color: #181825; border-bottom: 1px solid #313244;
    padding: 4px 8px 0 8px; min-height: 36px; }
.tab-title-btn { background-color: transparent; color: inherit; border: none;
    border-radius: 4px 0 0 4px; padding: 4px 8px; font-size: 13px; min-width: 60px; }
.tab-title-btn:hover { background-color: rgba(255,255,255,0.05); }
.tab-btn { background-color: #1e1e2e; color: #6c7086; border: 1px solid #313244;
    border-bottom: none; border-radius: 6px 6px 0 0; padding: 4px 10px; font-size: 13px; min-width: 80px; }
.tab-btn:hover { background-color: #313244; color: #cdd6f4; }
.tab-active { background-color: #1e1e2e; color: #cdd6f4; border: 1px solid #45475a;
    border-bottom: 2px solid #89b4fa; font-weight: bold; }
.badge-normal  { background-color: #313244; color: #a6e3a1; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; }
.badge-tor     { background-color: #7f49a0; color: #f5c2e7; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-i2p     { background-color: #1a6b3c; color: #a6e3a1; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-clear   { background-color: #313244; color: #a6e3a1; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-file    { background-color: #2a3550; color: #89b4fa; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-secure  { background-color: #1a4731; color: #a6e3a1; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-insecure{ background-color: #4a1a1a; color: #f38ba8; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-onion   { background-color: #7f49a0; color: #f5c2e7; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-eepsite { background-color: #1a6b3c; color: #a6e3a1; border-radius: 4px; padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.findbar       { background-color: #1e1e2e; border-top: 1px solid #313244; padding: 4px 8px; }
.findbar-entry { background-color: #313244; color: #cdd6f4; border: 1px solid #45475a;
    border-radius: 6px; padding: 2px 8px; font-size: 13px; min-height: 28px; min-width: 200px; }
.findbar-entry:focus { border-color: #89b4fa; }
.findbar-label { color: #6c7086; font-size: 12px; padding: 0 8px; }
.inspector-tv  { background-color: #0a0a1a; color: #89b4fa; font-family: monospace; font-size: 13px; padding: 10px; }
.terminal      { background-color: #0d0d0d; color: #00ff41; font-family: monospace; font-size: 13px; padding: 10px; }
.statusbar     { background-color: #181825; border-top: 1px solid #313244; color: #6c7086; font-size: 11px; padding: 2px 10px; }
.dl-progress trough { background-color: #313244; border-radius: 4px; min-height: 8px; }
.dl-progress progress { background-color: #89b4fa; border-radius: 4px; min-height: 8px; }
.new-tab-btn { background-color: transparent; color: #6c7086; border: none;
    border-radius: 4px; padding: 2px 8px; font-size: 18px; min-height: 28px; }
.new-tab-btn:hover { background-color: #313244; color: #cdd6f4; }
.sidebar       { background-color: #181825; border-right: 1px solid #313244; min-width: 240px; }
.sidebar-title { background-color: #1e1e2e; color: #89b4fa; font-weight: bold; font-size: 13px;
    padding: 8px 12px; border-bottom: 1px solid #313244; }
.sidebar-item  { background-color: transparent; color: #cdd6f4; border: none;
    border-radius: 4px; padding: 6px 10px; font-size: 12px; }
.sidebar-item:hover { background-color: #313244; }
.close-tab-btn { background-color: transparent; color: #6c7086; border: none;
    border-radius: 3px; padding: 0 3px; font-size: 12px; min-width: 16px; min-height: 16px; }
.close-tab-btn:hover { background-color: #f38ba8; color: #1e1e2e; }
)CSS";

// ─── JS de anti-fingerprinting (mismo que en Python/GJS) ──────────────────

static const char* FP_PROTECTION_JS = R"JS(
(function() {
    'use strict';
    // 1. LETTERBOXING
    (function() {
        function rounded(v, step) { return Math.floor(v / step) * step || step; }
        const RW = rounded(window.innerWidth,  100);
        const RH = rounded(window.innerHeight, 100);
        const props = { innerWidth: RW, innerHeight: RH, outerWidth: RW, outerHeight: RH };
        for (const [k, v] of Object.entries(props)) {
            try { Object.defineProperty(window, k, { get: () => v, configurable: true }); } catch(e) {}
        }
    })();
    // 2. TIMING ATTACKS
    (function() {
        const G = 2;
        const origNow = performance.now.bind(performance);
        performance.now = function() { return Math.round(origNow() / G) * G; };
        Date.now = (function(origDN) { return function() { return Math.round(origDN() / G) * G; }; })(Date.now);
        try { delete window.SharedArrayBuffer; } catch(e) {}
        try { delete window.Atomics; } catch(e) {}
    })();
    // 3. CANVAS
    (function() {
        const SEED = (Math.random() * 0xFFFFFFFF) | 0;
        function nb(i) { return ((SEED ^ (i * 1664525 + 1013904223)) >>> 24) & 1; }
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(t, ...a) {
            const ctx = this.getContext('2d');
            if (ctx && this.width > 0 && this.height > 0) {
                const id = ctx.getImageData(0, 0, this.width, this.height);
                for (let i = 0; i < id.data.length; i += 4) { id.data[i]^=nb(i); id.data[i+1]^=nb(i+1); id.data[i+2]^=nb(i+2); }
                ctx.putImageData(id, 0, 0);
            }
            return origToDataURL.call(this, t, ...a);
        };
    })();
    // 4. AUDIOCONTEXT
    (function() {
        const ACtx = window.AudioContext || window.webkitAudioContext;
        if (!ACtx) return;
        const P = function(...args) {
            const ctx = new ACtx(...args);
            const origCA = ctx.createAnalyser.bind(ctx);
            ctx.createAnalyser = function() {
                const a = origCA();
                const origGF = a.getFloatFrequencyData.bind(a);
                a.getFloatFrequencyData = function(arr) { origGF(arr); for (let i=0;i<arr.length;i++) arr[i]+=(Math.random()-0.5)*0.1; };
                return a;
            };
            return ctx;
        };
        try { if (window.AudioContext) window.AudioContext = P; } catch(e) {}
        try { if (window.webkitAudioContext) window.webkitAudioContext = P; } catch(e) {}
    })();
    // 5. NAVIGATOR
    (function() {
        const ov = { platform:'Win32', hardwareConcurrency:4, deviceMemory:8,
            languages:['en-US','en'], language:'en-US', plugins:[], mimeTypes:[],
            doNotTrack:'1', maxTouchPoints:0, vendor:'Google Inc.',
            vendorSub:'', productSub:'20030107', appName:'Netscape', appVersion:'5.0 (Windows)' };
        for (const [k,v] of Object.entries(ov)) {
            try { Object.defineProperty(navigator, k, { get: () => v, configurable: true }); } catch(e) {}
        }
    })();
    // 6. SCREEN
    (function() {
        const s = { width:1920, height:1080, availWidth:1920, availHeight:1080, colorDepth:24, pixelDepth:24 };
        for (const [k,v] of Object.entries(s)) {
            try { Object.defineProperty(screen, k, { get: () => v, configurable: true }); } catch(e) {}
        }
        try { Object.defineProperty(window, 'devicePixelRatio', { get: () => 1, configurable: true }); } catch(e) {}
    })();
    // 7. WEBGL
    (function() {
        function patchGL(ctx) {
            const ogp = ctx.getParameter.bind(ctx);
            ctx.getParameter = function(p) {
                if (p === 37445) return 'Intel Inc.';
                if (p === 37446) return 'Intel Iris OpenGL Engine';
                return ogp(p);
            };
            const oge = ctx.getExtension.bind(ctx);
            const blocked = ['WEBGL_debug_renderer_info','EXT_disjoint_timer_query','EXT_disjoint_timer_query_webgl2'];
            ctx.getExtension = function(n) { return blocked.includes(n) ? null : oge(n); };
            const ogs = ctx.getSupportedExtensions.bind(ctx);
            ctx.getSupportedExtensions = function() { return (ogs()||[]).filter(e=>!blocked.includes(e)); };
        }
        const origGC = HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext = function(t, ...a) {
            const ctx = origGC.call(this, t, ...a);
            if (ctx && (t==='webgl'||t==='webgl2'||t==='experimental-webgl')) patchGL(ctx);
            return ctx;
        };
    })();
    // 8. BATTERY
    if (navigator.getBattery) navigator.getBattery = () => Promise.resolve({ charging:true, chargingTime:0, dischargingTime:Infinity, level:1.0, addEventListener:()=>{}, removeEventListener:()=>{} });
    // 9. TIMEZONE
    Date.prototype.getTimezoneOffset = function() { return 0; };
    // 10. FUENTES
    if (document.fonts && document.fonts.check) {
        const gen = ['serif','sans-serif','monospace','cursive','fantasy','system-ui'];
        const oc = document.fonts.check.bind(document.fonts);
        document.fonts.check = (f, t) => gen.some(g => f.toLowerCase().includes(g)) ? oc(f, t) : false;
        const ol = document.fonts.load.bind(document.fonts);
        document.fonts.load = (f, t) => gen.some(g => f.toLowerCase().includes(g)) ? ol(f, t) : Promise.resolve([]);
    }
    // 11. WINDOW.NAME
    window.name = '';
    // 12. GEOLOCATION
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition = (ok, err) => { if (err) err({ code:1, message:'Permission denied' }); };
        navigator.geolocation.watchPosition = (ok, err) => { if (err) err({ code:1, message:'Permission denied' }); return 0; };
    }
    // 13. MEDIA DEVICES
    if (navigator.mediaDevices) {
        navigator.mediaDevices.enumerateDevices = () => Promise.resolve([]);
        navigator.mediaDevices.getUserMedia    = () => Promise.reject(new DOMException('NotAllowedError'));
        navigator.mediaDevices.getDisplayMedia = () => Promise.reject(new DOMException('NotAllowedError'));
    }
    // 14. SPEECH
    try { if (window.speechSynthesis) window.speechSynthesis.getVoices = () => []; delete window.SpeechRecognition; delete window.webkitSpeechRecognition; } catch(e) {}
})();
)JS";

// ─── Utilidades de cadenas ─────────────────────────────────────────────────

static std::string strLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

static bool startsWith(const std::string& s, const std::string& prefix) {
    return s.rfind(prefix, 0) == 0;
}

static bool endsWith(const std::string& s, const std::string& suffix) {
    if (suffix.size() > s.size()) return false;
    return s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}

static std::string urlEncode(const std::string& s) {
    gchar* enc = g_uri_escape_string(s.c_str(), nullptr, FALSE);
    std::string result(enc);
    g_free(enc);
    return result;
}

// Formato ISO de fecha actual
static std::string isoNow() {
    time_t t = time(nullptr);
    struct tm* tm_info = gmtime(&t);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", tm_info);
    return buf;
}

// ─── Estructuras de datos ─────────────────────────────────────────────────

struct TabData {
    WebKitWebView* webview = nullptr;
    std::string mode = "normal"; // "normal" | "tor" | "i2p"
};

// ─── Datos globales de la app ──────────────────────────────────────────────

struct AppData {
    std::string homeUri;
    bool darkMode = false;
    json history   = json::array();
    json bookmarks = json::array();

    void addHistory(const std::string& url, const std::string& title) {
        if (url.empty() || startsWith(url, "file://") || url == "about:blank") return;
        if (!history.empty() && history.back()["url"] == url) return;
        json entry;
        entry["url"]   = url;
        entry["title"] = title.empty() ? url : title;
        entry["ts"]    = isoNow();
        history.push_back(entry);
        if ((int)history.size() > 2000)
            history = json(history.end() - 2000, history.end());
        saveJson(historyFile(), history);
    }

    bool addBookmark(const std::string& url, const std::string& title) {
        if (url.empty() || url == "about:blank") return false;
        for (const auto& b : bookmarks)
            if (b["url"] == url) return false;
        json bm; bm["url"] = url; bm["title"] = title.empty() ? url : title;
        bookmarks.push_back(bm);
        saveJson(bookmarksFile(), bookmarks);
        return true;
    }

    void removeBookmark(const std::string& url) {
        json nb = json::array();
        for (const auto& b : bookmarks)
            if (b["url"] != url) nb.push_back(b);
        bookmarks = nb;
        saveJson(bookmarksFile(), bookmarks);
    }

    bool isBookmarked(const std::string& url) const {
        for (const auto& b : bookmarks)
            if (b["url"] == url) return true;
        return false;
    }
};

// ─── Contexto de la ventana ────────────────────────────────────────────────
// Usamos una struct con todos los widgets y estado porque gtkmm no está
// disponible en todos los entornos; esto usa la C API pura de GTK4.

struct BrowserWindow {
    GtkApplicationWindow* window = nullptr;
    AppData* app = nullptr;

    // Pestañas
    std::vector<TabData> tabs;
    int currentTab = -1;

    // Widgets
    GtkBox*       tabbarBox     = nullptr;
    GtkStack*     tabStack      = nullptr;
    GtkEntry*     urlEntry      = nullptr;
    GtkButton*    backBtn       = nullptr;
    GtkButton*    forwardBtn    = nullptr;
    GtkButton*    reloadBtn     = nullptr;
    GtkButton*    bookmarkStar  = nullptr;
    GtkLabel*     badge         = nullptr;
    GtkLabel*     secBadge      = nullptr;
    GtkLabel*     statusbar     = nullptr;
    GtkProgressBar* dlProgress  = nullptr;
    GtkBox*       contentArea   = nullptr;
    GtkWidget*    sidebarWidget = nullptr;

    // Terminal
    GtkTextBuffer* terminalBuf  = nullptr;
    GtkTextView*   terminalTv   = nullptr;
    GtkScrolledWindow* termScroll = nullptr;
    GtkTextMark*   promptEndMark = nullptr;
    bool terminalVisible = false;

    // Inspector
    GtkTextBuffer* inspectorBuf = nullptr;
    GtkTextView*   inspectorTv  = nullptr;
    GtkWidget*     inspPanel    = nullptr;
    bool inspectorMode = false;

    // Findbar
    GtkBox*   findbarBox   = nullptr;
    GtkEntry* findEntry    = nullptr;
    GtkLabel* findLabel    = nullptr;
    bool findbarVisible = false;

    // Sidebar
    std::string sidebarMode; // "" | "bookmarks" | "history"
};

// Puntero global para acceder desde callbacks C
static BrowserWindow* g_bw = nullptr;
static AppData g_app;

// ─── Helpers de botones ────────────────────────────────────────────────────

static GtkButton* makeNavBtn(const char* label, const char* tooltip, GCallback cb, gpointer data) {
    GtkButton* b = GTK_BUTTON(gtk_button_new_with_label(label));
    gtk_widget_add_css_class(GTK_WIDGET(b), "nav-button");
    gtk_widget_set_tooltip_text(GTK_WIDGET(b), tooltip);
    g_signal_connect(b, "clicked", cb, data);
    return b;
}

// ─── Creación de WebView ────────────────────────────────────────────────────

static WebKitWebView* makeWebview(BrowserWindow* bw, const std::string& mode);

// Callbacks de señales del WebView (declaraciones adelantadas)
static void onUriChanged(GObject* obj, GParamSpec*, gpointer data);
static void onTitleChanged(GObject* obj, GParamSpec*, gpointer data);
static void onLoadChanged(WebKitWebView* wv, WebKitLoadEvent event, gpointer data);
static void onProgress(GObject* obj, GParamSpec*, gpointer data);

static WebKitWebView* makeWebview(BrowserWindow* bw, const std::string& mode) {
    WebKitWebView* wv = nullptr;

    if (mode == "tor" || mode == "i2p") {
        WebKitNetworkSession* ns = webkit_network_session_new_ephemeral();
        const char* proxyUrl = mode == "tor" ? "socks5://127.0.0.1:9050" : "http://127.0.0.1:4444";
        WebKitNetworkProxySettings* ps = webkit_network_proxy_settings_new(proxyUrl, nullptr);
        webkit_network_session_set_proxy_settings(ns, WEBKIT_NETWORK_PROXY_MODE_CUSTOM, ps);
        webkit_network_proxy_settings_free(ps);
        // En WebKit6 se pasa network-session como propiedad de construcción
        wv = WEBKIT_WEB_VIEW(g_object_new(WEBKIT_TYPE_WEB_VIEW,
            "network-session", ns, nullptr));
        g_object_unref(ns);
    } else {
        wv = WEBKIT_WEB_VIEW(webkit_web_view_new());
    }

    // Configuración de seguridad
    WebKitSettings* s = webkit_settings_new();
    webkit_settings_set_enable_developer_extras(s, FALSE);
    webkit_settings_set_javascript_can_access_clipboard(s, FALSE);
    webkit_settings_set_enable_webrtc(s, FALSE);
    webkit_settings_set_enable_mediasource(s, FALSE);
    webkit_settings_set_enable_encrypted_media(s, FALSE);
    webkit_settings_set_enable_back_forward_navigation_gestures(s, FALSE);
    webkit_settings_set_media_playback_requires_user_gesture(s, TRUE);
    webkit_settings_set_javascript_can_open_windows_automatically(s, FALSE);
    webkit_settings_set_allow_modal_dialogs(s, FALSE);
    webkit_settings_set_enable_page_cache(s, FALSE);
    webkit_settings_set_user_agent(s,
        "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0");
    webkit_web_view_set_settings(wv, s);
    g_object_unref(s);

    gtk_widget_set_vexpand(GTK_WIDGET(wv), TRUE);
    gtk_widget_set_hexpand(GTK_WIDGET(wv), TRUE);

    // Señales
    g_signal_connect(wv, "notify::uri",   G_CALLBACK(onUriChanged),   bw);
    g_signal_connect(wv, "notify::title", G_CALLBACK(onTitleChanged), bw);
    g_signal_connect(wv, "load-changed",  G_CALLBACK(onLoadChanged),  bw);
    g_signal_connect(wv, "notify::estimated-load-progress", G_CALLBACK(onProgress), bw);

    // Anti-fingerprinting
    WebKitUserContentManager* ucm = webkit_web_view_get_user_content_manager(wv);
    WebKitUserScript* fpScript = webkit_user_script_new(
        FP_PROTECTION_JS,
        WEBKIT_USER_CONTENT_INJECT_TOP_FRAME,
        WEBKIT_USER_SCRIPT_INJECT_AT_DOCUMENT_START,
        nullptr, nullptr
    );
    webkit_user_content_manager_add_script(ucm, fpScript);
    webkit_user_script_unref(fpScript);

    return wv;
}

// ─── Funciones de gestión de pestañas ──────────────────────────────────────

static WebKitWebView* currentWv(BrowserWindow* bw) {
    return bw->tabs[bw->currentTab].webview;
}

static TabData& currentTd(BrowserWindow* bw) {
    return bw->tabs[bw->currentTab];
}

static void updateBadge(BrowserWindow* bw, const std::string& mode);
static void updateNavButtons(BrowserWindow* bw);
static void updateBookmarkStar(BrowserWindow* bw);
static void updateSecurityBadge(BrowserWindow* bw, const std::string& uri);
static void setupDownloadHandler(BrowserWindow* bw, WebKitWebView* wv);
static void switchTab(BrowserWindow* bw, int idx);
static void clearTabData(BrowserWindow* bw, TabData& td);
static void rebuildTabbar(BrowserWindow* bw);
static void openTab(BrowserWindow* bw, const char* uri = nullptr, const std::string& mode = "normal");
static void onCloseTab(BrowserWindow* bw, int idx);

// Callbacks de pestaña
struct TabCallbackData { BrowserWindow* bw; int idx; };

static void onTabTitleBtnClicked(GtkButton*, gpointer data) {
    auto* d = static_cast<TabCallbackData*>(data);
    switchTab(d->bw, d->idx);
}
static void onCloseTabBtnClicked(GtkButton*, gpointer data) {
    auto* d = static_cast<TabCallbackData*>(data);
    onCloseTab(d->bw, d->idx);
}

static GtkBox* makeTabWidget(BrowserWindow* bw, int idx) {
    GtkBox* box = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0));
    gtk_widget_add_css_class(GTK_WIDGET(box), "tab-btn");

    std::string tabLabel = "Tab " + std::to_string(idx + 1);
    GtkButton* titleBtn = GTK_BUTTON(gtk_button_new_with_label(tabLabel.c_str()));
    gtk_widget_add_css_class(GTK_WIDGET(titleBtn), "tab-title-btn");
    gtk_widget_set_hexpand(GTK_WIDGET(titleBtn), TRUE);

    auto* td = new TabCallbackData{bw, idx};
    g_signal_connect_data(titleBtn, "clicked", G_CALLBACK(onTabTitleBtnClicked),
        td, [](gpointer p, GClosure*) { delete static_cast<TabCallbackData*>(p); }, GConnectFlags(0));

    GtkButton* closeBtn = GTK_BUTTON(gtk_button_new_with_label("x"));
    gtk_widget_add_css_class(GTK_WIDGET(closeBtn), "close-tab-btn");

    auto* cd = new TabCallbackData{bw, idx};
    g_signal_connect_data(closeBtn, "clicked", G_CALLBACK(onCloseTabBtnClicked),
        cd, [](gpointer p, GClosure*) { delete static_cast<TabCallbackData*>(p); }, GConnectFlags(0));

    // Guardar referencia al botón de título en qdata
    g_object_set_data(G_OBJECT(box), "title-btn", titleBtn);

    gtk_box_append(box, GTK_WIDGET(titleBtn));
    gtk_box_append(box, GTK_WIDGET(closeBtn));
    return box;
}

static void openTab(BrowserWindow* bw, const char* uri, const std::string& mode) {
    WebKitWebView* wv = makeWebview(bw, mode);
    TabData td; td.webview = wv; td.mode = mode;
    bw->tabs.push_back(td);
    int idx = (int)bw->tabs.size() - 1;

    std::string name = "tab" + std::to_string(idx);
    gtk_stack_add_named(bw->tabStack, GTK_WIDGET(wv), name.c_str());

    GtkBox* tabWidget = makeTabWidget(bw, idx);
    gtk_box_append(bw->tabbarBox, GTK_WIDGET(tabWidget));

    setupDownloadHandler(bw, wv);
    switchTab(bw, idx);

    std::string loadUri = uri ? std::string(uri) : bw->app->homeUri;
    webkit_web_view_load_uri(wv, loadUri.c_str());
}

static void clearTabData(BrowserWindow*, TabData& td) {
    WebKitNetworkSession* ns = webkit_web_view_get_network_session(td.webview);
    if (!ns) return;
    WebKitWebsiteDataManager* wdm = webkit_network_session_get_website_data_manager(ns);
    if (!wdm) return;
    webkit_website_data_manager_clear(wdm,
        (WebKitWebsiteDataTypes)(
            WEBKIT_WEBSITE_DATA_COOKIES |
            WEBKIT_WEBSITE_DATA_DISK_CACHE |
            WEBKIT_WEBSITE_DATA_MEMORY_CACHE |
            WEBKIT_WEBSITE_DATA_SESSION_STORAGE |
            WEBKIT_WEBSITE_DATA_LOCAL_STORAGE |
            WEBKIT_WEBSITE_DATA_INDEXEDDB_DATABASES |
            WEBKIT_WEBSITE_DATA_OFFLINE_APPLICATION_CACHE
        ),
        0, nullptr, nullptr, nullptr);
}

static void rebuildTabbar(BrowserWindow* bw) {
    GtkWidget* child = gtk_widget_get_first_child(GTK_WIDGET(bw->tabbarBox));
    while (child) {
        GtkWidget* next = gtk_widget_get_next_sibling(child);
        gtk_box_remove(bw->tabbarBox, child);
        child = next;
    }
    for (int i = 0; i < (int)bw->tabs.size(); i++) {
        GtkBox* tw = makeTabWidget(bw, i);
        const char* title = webkit_web_view_get_title(bw->tabs[i].webview);
        if (title) {
            GtkButton* titleBtn = GTK_BUTTON(g_object_get_data(G_OBJECT(tw), "title-btn"));
            std::string t(title);
            if ((int)t.size() > 14) t = t.substr(0, 14) + "...";
            gtk_button_set_label(titleBtn, t.c_str());
        }
        gtk_box_append(bw->tabbarBox, GTK_WIDGET(tw));
    }
}

static void onCloseTab(BrowserWindow* bw, int idx) {
    if ((int)bw->tabs.size() == 1) {
        webkit_web_view_load_uri(bw->tabs[0].webview, bw->app->homeUri.c_str());
        return;
    }
    clearTabData(bw, bw->tabs[idx]);
    GtkWidget* child = gtk_stack_get_child_by_name(bw->tabStack,
        ("tab" + std::to_string(idx)).c_str());
    if (child) gtk_stack_remove(bw->tabStack, child);
    bw->tabs.erase(bw->tabs.begin() + idx);
    rebuildTabbar(bw);
    switchTab(bw, std::min(idx, (int)bw->tabs.size() - 1));
}

static void switchTab(BrowserWindow* bw, int idx) {
    if (idx < 0 || idx >= (int)bw->tabs.size()) return;

    // Actualizar estilos de pestañas
    GtkWidget* child = gtk_widget_get_first_child(GTK_WIDGET(bw->tabbarBox));
    int i = 0;
    while (child) {
        gtk_widget_remove_css_class(child, "tab-active");
        if (i == idx) gtk_widget_add_css_class(child, "tab-active");
        child = gtk_widget_get_next_sibling(child);
        i++;
    }

    bw->currentTab = idx;
    std::string name = "tab" + std::to_string(idx);
    gtk_stack_set_visible_child_name(bw->tabStack, name.c_str());

    const char* uri = webkit_web_view_get_uri(bw->tabs[idx].webview);
    gtk_editable_set_text(GTK_EDITABLE(bw->urlEntry), (uri && std::string(uri) != "about:blank") ? uri : "");
    updateBadge(bw, bw->tabs[idx].mode);
    updateNavButtons(bw);
    updateBookmarkStar(bw);
    updateSecurityBadge(bw, uri ? uri : "");
}

// ─── Señales del WebView ────────────────────────────────────────────────────

static void onUriChanged(GObject* obj, GParamSpec*, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    auto* wv = WEBKIT_WEB_VIEW(obj);
    if (bw->tabs.empty()) return;
    const char* uri = webkit_web_view_get_uri(wv);
    if (!uri || std::string(uri) == "about:blank") return;
    if (wv == currentWv(bw)) {
        gtk_editable_set_text(GTK_EDITABLE(bw->urlEntry), uri);
        updateBookmarkStar(bw);
        updateNavButtons(bw);
        updateSecurityBadge(bw, uri);
    }
    const char* title = webkit_web_view_get_title(wv);
    bw->app->addHistory(uri, title ? title : uri);
}

static void onTitleChanged(GObject* obj, GParamSpec*, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    auto* wv = WEBKIT_WEB_VIEW(obj);
    if (bw->tabs.empty()) return;
    const char* titleRaw = webkit_web_view_get_title(wv);
    std::string title = titleRaw ? titleRaw : "";

    GtkWidget* child = gtk_widget_get_first_child(GTK_WIDGET(bw->tabbarBox));
    int i = 0;
    while (child) {
        if (i < (int)bw->tabs.size() && bw->tabs[i].webview == wv) {
            GtkButton* btn = GTK_BUTTON(g_object_get_data(G_OBJECT(child), "title-btn"));
            if (btn) {
                std::string short_ = title.empty() ? ("Tab " + std::to_string(i + 1)) :
                    (title.size() > 14 ? title.substr(0, 14) + "..." : title);
                gtk_button_set_label(btn, short_.c_str());
            }
            break;
        }
        child = gtk_widget_get_next_sibling(child);
        i++;
    }
    if (wv == currentWv(bw)) {
        std::string winTitle = title.empty() ? "PrekT-BR" : "PrekT-BR — " + title;
        gtk_window_set_title(GTK_WINDOW(bw->window), winTitle.c_str());
    }
}

static void onLoadChanged(WebKitWebView* wv, WebKitLoadEvent event, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    if (event == WEBKIT_LOAD_STARTED) {
        gtk_button_set_label(bw->reloadBtn, "✕");
        gtk_widget_set_tooltip_text(GTK_WIDGET(bw->reloadBtn), "Detener carga");
    } else if (event == WEBKIT_LOAD_FINISHED) {
        gtk_button_set_label(bw->reloadBtn, "↻");
        gtk_widget_set_tooltip_text(GTK_WIDGET(bw->reloadBtn), "Recargar (Ctrl+R)");
        gtk_label_set_text(bw->statusbar, "");
    }
}

static void onProgress(GObject* obj, GParamSpec*, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    auto* wv = WEBKIT_WEB_VIEW(obj);
    if (wv != currentWv(bw)) return;
    double p = webkit_web_view_get_estimated_load_progress(wv);
    if (p > 0 && p < 1) {
        std::string msg = "Cargando… " + std::to_string((int)(p * 100)) + "%";
        gtk_label_set_text(bw->statusbar, msg.c_str());
    } else {
        gtk_label_set_text(bw->statusbar, "");
    }
}

// ─── Navegación ────────────────────────────────────────────────────────────

static std::string resolveInput(BrowserWindow* bw, const std::string& text) {
    std::string lower = strLower(text);
    for (const char* scheme : {"javascript:", "data:", "vbscript:", "blob:"}) {
        if (startsWith(lower, scheme)) {
            std::string msg = std::string("Esquema bloqueado: ") + scheme;
            gtk_label_set_text(bw->statusbar, msg.c_str());
            return "about:blank";
        }
    }
    if (startsWith(text, "http://") || startsWith(text, "https://") ||
        startsWith(text, "about:")  || startsWith(text, "file://"))
        return text;
    if (text.find('.') != std::string::npos && text.find(' ') == std::string::npos)
        return "https://" + text;
    return "https://duckduckgo.com/?q=" + urlEncode(text);
}

static void updateNavButtons(BrowserWindow* bw) {
    if (bw->tabs.empty()) return;
    auto* wv = currentWv(bw);
    gtk_widget_set_sensitive(GTK_WIDGET(bw->backBtn),    webkit_web_view_can_go_back(wv));
    gtk_widget_set_sensitive(GTK_WIDGET(bw->forwardBtn), webkit_web_view_can_go_forward(wv));
}

// ─── Badge de red ──────────────────────────────────────────────────────────

static void updateBadge(BrowserWindow* bw, const std::string& mode) {
    GtkWidget* w = GTK_WIDGET(bw->badge);
    for (const char* cls : {"badge-normal","badge-tor","badge-i2p","badge-clear"})
        gtk_widget_remove_css_class(w, cls);
    if (mode == "tor") {
        gtk_label_set_text(bw->badge, "TOR");
        gtk_widget_add_css_class(w, "badge-tor");
    } else if (mode == "i2p") {
        gtk_label_set_text(bw->badge, "I2P");
        gtk_widget_add_css_class(w, "badge-i2p");
    } else {
        gtk_label_set_text(bw->badge, "Clear");
        gtk_widget_add_css_class(w, "badge-clear");
    }
    gtk_widget_set_visible(w, TRUE);
}

// ─── Badge de seguridad ────────────────────────────────────────────────────

static void updateSecurityBadge(BrowserWindow* bw, const std::string& uri) {
    GtkWidget* w = GTK_WIDGET(bw->secBadge);
    if (uri.empty() || startsWith(uri, "about:")) { gtk_widget_set_visible(w, FALSE); return; }

    // Parsear esquema y host
    GUri* guri = g_uri_parse(uri.c_str(), G_URI_FLAGS_NONE, nullptr);
    if (!guri) { gtk_widget_set_visible(w, FALSE); return; }
    std::string scheme = g_uri_get_scheme(guri) ? g_uri_get_scheme(guri) : "";
    std::string host   = g_uri_get_host(guri)   ? g_uri_get_host(guri)   : "";
    g_uri_unref(guri);

    for (const char* cls : {"badge-secure","badge-insecure","badge-onion","badge-eepsite","badge-file"})
        gtk_widget_remove_css_class(w, cls);

    if (scheme == "file") {
        gtk_label_set_text(bw->secBadge, "F");
        gtk_widget_add_css_class(w, "badge-file");
        gtk_widget_set_tooltip_text(w, "Archivo local");
    } else if (endsWith(host, ".onion")) {
        gtk_label_set_text(bw->secBadge, "O");
        gtk_widget_add_css_class(w, "badge-onion");
        gtk_widget_set_tooltip_text(w, "Onion — servicio oculto Tor");
    } else if (endsWith(host, ".i2p") || endsWith(host, ".loki")) {
        gtk_label_set_text(bw->secBadge, "E");
        gtk_widget_add_css_class(w, "badge-eepsite");
        gtk_widget_set_tooltip_text(w, "Eepsite — servicio I2P/Lokinet");
    } else if (scheme == "https") {
        gtk_label_set_text(bw->secBadge, "S");
        gtk_widget_add_css_class(w, "badge-secure");
        gtk_widget_set_tooltip_text(w, "Seguro — conexión HTTPS");
    } else {
        gtk_label_set_text(bw->secBadge, "I");
        gtk_widget_add_css_class(w, "badge-insecure");
        gtk_widget_set_tooltip_text(w, "Inseguro — conexión HTTP sin cifrar");
    }
    gtk_widget_set_visible(w, TRUE);
}

// ─── Marcadores ────────────────────────────────────────────────────────────

static void updateBookmarkStar(BrowserWindow* bw) {
    if (bw->tabs.empty()) return;
    const char* uri = webkit_web_view_get_uri(currentWv(bw));
    bool bookmarked = uri && bw->app->isBookmarked(uri);
    gtk_button_set_label(bw->bookmarkStar, bookmarked ? "★" : "☆");
}

// ─── Terminal ──────────────────────────────────────────────────────────────

static void termPrint(BrowserWindow* bw, const std::string& text, bool noNl = false) {
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(bw->terminalBuf, &end);
    std::string msg = noNl ? text : text + "\n";
    gtk_text_buffer_insert(bw->terminalBuf, &end, msg.c_str(), -1);
    GtkTextIter end2;
    gtk_text_buffer_get_end_iter(bw->terminalBuf, &end2);
    gtk_text_view_scroll_to_iter(bw->terminalTv, &end2, 0.0, TRUE, 0.0, 1.0);
}

static void termPrompt(BrowserWindow* bw) {
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(bw->terminalBuf, &end);
    gtk_text_buffer_insert(bw->terminalBuf, &end, "> ", -1);
    GtkTextIter end2;
    gtk_text_buffer_get_end_iter(bw->terminalBuf, &end2);
    bw->promptEndMark = gtk_text_buffer_create_mark(bw->terminalBuf, "prompt_end", &end2, TRUE);
}

// ─── Findbar ────────────────────────────────────────────────────────────────

static void closeFindbar(BrowserWindow* bw) {
    gtk_widget_set_visible(GTK_WIDGET(bw->findbarBox), FALSE);
    bw->findbarVisible = false;
    webkit_find_controller_search_finish(webkit_web_view_get_find_controller(currentWv(bw)));
    gtk_label_set_text(bw->findLabel, "");
}

static void findChanged(BrowserWindow* bw) {
    const char* text = gtk_editable_get_text(GTK_EDITABLE(bw->findEntry));
    WebKitFindController* fc = webkit_web_view_get_find_controller(currentWv(bw));
    if (text && text[0])
        webkit_find_controller_search(fc, text,
            (WebKitFindOptions)(WEBKIT_FIND_OPTIONS_CASE_INSENSITIVE | WEBKIT_FIND_OPTIONS_WRAP_AROUND), 1000);
    else {
        webkit_find_controller_search_finish(fc);
        gtk_label_set_text(bw->findLabel, "");
    }
}

// ─── Modo oscuro ────────────────────────────────────────────────────────────

static void applyDarkCss(BrowserWindow* bw) {
    const char* css = ":root{color-scheme:dark!important}"
                      "*{background-color:#111!important;color:#eee!important;border-color:#333!important}"
                      "a{color:#8ab4f8!important}img{filter:brightness(0.85)}";
    std::string js = R"((function(){let el=document.getElementById('prektbr-dark');)"
                     R"(if(!el){el=document.createElement('style');el.id='prektbr-dark';document.head.appendChild(el);}"
                     R"(el.textContent=`)" + std::string(css) + R"(`;})();)";
    webkit_web_view_evaluate_javascript(currentWv(bw), js.c_str(), -1,
        nullptr, nullptr, nullptr, nullptr, nullptr);
}

// ─── Sidebar (marcadores / historial) ─────────────────────────────────────

struct SidebarItemData { BrowserWindow* bw; std::string url; bool removable; };

static void closeSidebar(BrowserWindow* bw) {
    if (bw->sidebarWidget) {
        gtk_box_remove(bw->contentArea, bw->sidebarWidget);
        g_object_unref(bw->sidebarWidget); // soltar la ref extra que tomamos al crear
        bw->sidebarWidget = nullptr;
    }
    bw->sidebarMode = "";
}

static void showSidebar(BrowserWindow* bw, const std::string& mode);

static void sidebarItemClicked(GtkButton*, gpointer data) {
    auto* d = static_cast<SidebarItemData*>(data);
    webkit_web_view_load_uri(currentWv(d->bw), d->url.c_str());
}

static void sidebarItemRemoveClicked(GtkButton*, gpointer data) {
    auto* d = static_cast<SidebarItemData*>(data);
    d->bw->app->removeBookmark(d->url);
    showSidebar(d->bw, "bookmarks");
}

static void addSidebarItem(GtkBox* listBox, BrowserWindow* bw,
                           const std::string& label, const std::string& url,
                           bool removable) {
    GtkBox* row = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2));

    GtkButton* btn = GTK_BUTTON(gtk_button_new_with_label(label.c_str()));
    gtk_widget_add_css_class(GTK_WIDGET(btn), "sidebar-item");
    gtk_widget_set_hexpand(GTK_WIDGET(btn), TRUE);
    gtk_widget_set_halign(GTK_WIDGET(btn), GTK_ALIGN_FILL);

    auto* itemData = new SidebarItemData{bw, url, removable};
    g_signal_connect_data(btn, "clicked", G_CALLBACK(sidebarItemClicked),
        itemData, [](gpointer p, GClosure*) { delete static_cast<SidebarItemData*>(p); },
        GConnectFlags(0));
    gtk_box_append(row, GTK_WIDGET(btn));

    if (removable) {
        GtkButton* del = GTK_BUTTON(gtk_button_new_with_label("Quitar"));
        gtk_widget_add_css_class(GTK_WIDGET(del), "close-tab-btn");
        auto* delData = new SidebarItemData{bw, url, true};
        g_signal_connect_data(del, "clicked", G_CALLBACK(sidebarItemRemoveClicked),
            delData, [](gpointer p, GClosure*) { delete static_cast<SidebarItemData*>(p); },
            GConnectFlags(0));
        gtk_box_append(row, GTK_WIDGET(del));
    }

    gtk_box_append(listBox, GTK_WIDGET(row));
}

static void showSidebar(BrowserWindow* bw, const std::string& mode) {
    closeSidebar(bw);
    bw->sidebarMode = mode;

    GtkBox* outer = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 0));
    gtk_widget_add_css_class(GTK_WIDGET(outer), "sidebar");

    // Cabecera
    GtkBox* titleBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0));
    gtk_widget_add_css_class(GTK_WIDGET(titleBox), "sidebar-title");

    GtkLabel* lbl = GTK_LABEL(gtk_label_new(mode == "bookmarks" ? "Marcadores" : "Historial"));
    gtk_widget_set_hexpand(GTK_WIDGET(lbl), TRUE);
    gtk_label_set_xalign(lbl, 0.0f);

    GtkButton* closeBtn = GTK_BUTTON(gtk_button_new_with_label("Cerrar"));
    gtk_widget_add_css_class(GTK_WIDGET(closeBtn), "nav-button");
    g_signal_connect_data(closeBtn, "clicked",
        G_CALLBACK(+[](GtkButton*, gpointer p) { closeSidebar(static_cast<BrowserWindow*>(p)); }),
        bw, nullptr, GConnectFlags(0));

    gtk_box_append(titleBox, GTK_WIDGET(lbl));
    gtk_box_append(titleBox, GTK_WIDGET(closeBtn));

    // Lista con scroll
    GtkScrolledWindow* scroll = GTK_SCROLLED_WINDOW(gtk_scrolled_window_new());
    gtk_widget_set_vexpand(GTK_WIDGET(scroll), TRUE);
    gtk_scrolled_window_set_policy(scroll, GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);

    GtkBox* listBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 1));
    gtk_widget_set_margin_top(GTK_WIDGET(listBox), 4);
    gtk_widget_set_margin_bottom(GTK_WIDGET(listBox), 4);
    gtk_widget_set_margin_start(GTK_WIDGET(listBox), 4);
    gtk_widget_set_margin_end(GTK_WIDGET(listBox), 4);

    if (mode == "bookmarks") {
        if (bw->app->bookmarks.empty()) {
            GtkLabel* empty = GTK_LABEL(gtk_label_new("Sin marcadores aún"));
            gtk_widget_set_margin_top(GTK_WIDGET(empty), 20);
            gtk_widget_add_css_class(GTK_WIDGET(empty), "sidebar-item");
            gtk_box_append(listBox, GTK_WIDGET(empty));
        } else {
            for (const auto& b : bw->app->bookmarks)
                addSidebarItem(listBox, bw,
                    b["title"].get<std::string>(),
                    b["url"].get<std::string>(), true);
        }
    } else {
        // Historial — últimas 200 entradas en orden inverso
        int total = (int)bw->app->history.size();
        int start = std::max(0, total - 200);
        if (total == 0) {
            GtkLabel* empty = GTK_LABEL(gtk_label_new("El historial está vacío"));
            gtk_widget_set_margin_top(GTK_WIDGET(empty), 20);
            gtk_widget_add_css_class(GTK_WIDGET(empty), "sidebar-item");
            gtk_box_append(listBox, GTK_WIDGET(empty));
        } else {
            for (int i = total - 1; i >= start; i--) {
                const auto& h = bw->app->history[i];
                std::string ts = h.value("ts", "").substr(0, 10);
                std::string label = "[" + ts + "] " + h.value("title", h.value("url", ""));
                addSidebarItem(listBox, bw, label, h.value("url", ""), false);
            }
        }
    }

    gtk_scrolled_window_set_child(scroll, GTK_WIDGET(listBox));
    gtk_box_append(outer, GTK_WIDGET(titleBox));
    gtk_box_append(outer, GTK_WIDGET(scroll));

    // Tomar ref extra para sobrevivir a futuros removes
    g_object_ref(outer);
    bw->sidebarWidget = GTK_WIDGET(outer);

    // Insertar ANTES del tab stack (prepend al contentArea)
    gtk_box_prepend(bw->contentArea, GTK_WIDGET(outer));
}

static void toggleSidebar(BrowserWindow* bw, const std::string& mode) {
    if (bw->sidebarMode == mode) closeSidebar(bw);
    else showSidebar(bw, mode);
}



struct DownloadCtx { BrowserWindow* bw; std::string filename; };

static void onDownloadFailed(WebKitDownload*, GError* error, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    std::string msg = std::string("Error de descarga: ") + (error ? error->message : "desconocido");
    gtk_label_set_text(bw->statusbar, msg.c_str());
    gtk_progress_bar_set_fraction(bw->dlProgress, 0);
    gtk_widget_set_visible(GTK_WIDGET(bw->dlProgress), FALSE);
}

static void onDownloadProgress(GObject* obj, GParamSpec*, gpointer data) {
    auto* ctx = static_cast<DownloadCtx*>(data);
    auto* dl  = WEBKIT_DOWNLOAD(obj);
    double p  = webkit_download_get_estimated_progress(dl);
    std::string msg = "Descargando: " + ctx->filename + "  " + std::to_string((int)(p*100)) + "%";
    gtk_label_set_text(ctx->bw->statusbar, msg.c_str());
    gtk_progress_bar_set_fraction(ctx->bw->dlProgress, p);
}

static void onDownloadFinished(WebKitDownload*, gpointer data) {
    auto* ctx = static_cast<DownloadCtx*>(data);
    std::string msg = "Descarga completa: " + ctx->filename;
    gtk_progress_bar_set_fraction(ctx->bw->dlProgress, 1.0);
    gtk_label_set_text(ctx->bw->statusbar, msg.c_str());
    auto* bw = ctx->bw;
    g_timeout_add(3500, [](gpointer p) -> gboolean {
        auto* bw2 = static_cast<BrowserWindow*>(p);
        gtk_widget_set_visible(GTK_WIDGET(bw2->dlProgress), FALSE);
        gtk_progress_bar_set_fraction(bw2->dlProgress, 0);
        gtk_label_set_text(bw2->statusbar, "");
        return FALSE;
    }, bw);
    delete ctx;
}

static void onSaveDialogDone(GObject* source, GAsyncResult* result, gpointer data) {
    GtkFileDialog* dialog = GTK_FILE_DIALOG(source);
    auto* pair = static_cast<std::pair<BrowserWindow*, WebKitDownload*>*>(data);
    BrowserWindow* bw = pair->first;
    WebKitDownload* dl = pair->second;
    delete pair;

    GFile* gfile = gtk_file_dialog_save_finish(dialog, result, nullptr);
    if (!gfile) { webkit_download_cancel(dl); return; }

    char* path = g_file_get_path(gfile);
    g_object_unref(gfile);
    if (!path) { webkit_download_cancel(dl); return; }

    webkit_download_set_destination(dl, path);
    std::string fname = g_path_get_basename(path);
    g_free(path);

    gtk_progress_bar_set_fraction(bw->dlProgress, 0);
    gtk_widget_set_visible(GTK_WIDGET(bw->dlProgress), TRUE);
    gtk_label_set_text(bw->statusbar, ("Descargando: " + fname + "  0%").c_str());

    auto* ctx = new DownloadCtx{bw, fname};
    g_signal_connect(dl, "notify::estimated-progress", G_CALLBACK(onDownloadProgress), ctx);
    g_signal_connect(dl, "finished", G_CALLBACK(onDownloadFinished), ctx);
}

static gboolean onDecideDestination(WebKitDownload* dl, const char* fname, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    std::string suggestedName = fname ? fname : "descarga";

    GtkFileDialog* dialog = gtk_file_dialog_new();
    gtk_file_dialog_set_title(dialog, "Guardar archivo");
    gtk_file_dialog_set_initial_name(dialog, suggestedName.c_str());

    auto* pair = new std::pair<BrowserWindow*, WebKitDownload*>{bw, dl};
    gtk_file_dialog_save(dialog, GTK_WINDOW(bw->window), nullptr,
        onSaveDialogDone, pair);
    g_object_unref(dialog);
    return TRUE;
}

static void onDownloadStarted(WebKitNetworkSession*, WebKitDownload* dl, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    g_signal_connect(dl, "decide-destination", G_CALLBACK(onDecideDestination), bw);
    g_signal_connect(dl, "failed", G_CALLBACK(onDownloadFailed), bw);
}

static void setupDownloadHandler(BrowserWindow* bw, WebKitWebView* wv) {
    WebKitNetworkSession* ns = webkit_web_view_get_network_session(wv);
    if (ns) g_signal_connect(ns, "download-started", G_CALLBACK(onDownloadStarted), bw);
}

// ─── Modos de red ──────────────────────────────────────────────────────────

static void enableNetworkMode(BrowserWindow* bw, const std::string& mode) {
    TabData& td = currentTd(bw);
    if (td.mode == mode) {
        termPrint(bw, "La pestaña ya está en modo " + strLower(mode) + ".");
        termPrompt(bw);
        return;
    }
    const char* oldUri = webkit_web_view_get_uri(td.webview);
    std::string oldUriStr = oldUri ? oldUri : bw->app->homeUri;

    WebKitWebView* newWv = makeWebview(bw, mode);
    int idx = bw->currentTab;

    GtkWidget* old = gtk_stack_get_child_by_name(bw->tabStack, ("tab" + std::to_string(idx)).c_str());
    if (old) gtk_stack_remove(bw->tabStack, old);

    td.webview = newWv;
    td.mode    = mode;
    gtk_stack_add_named(bw->tabStack, GTK_WIDGET(newWv), ("tab" + std::to_string(idx)).c_str());
    gtk_stack_set_visible_child_name(bw->tabStack, ("tab" + std::to_string(idx)).c_str());
    setupDownloadHandler(bw, newWv);
    webkit_web_view_load_uri(newWv, (oldUriStr != "about:blank" ? oldUriStr : bw->app->homeUri).c_str());
    updateBadge(bw, mode);

    if (mode == "tor") {
        termPrint(bw, "  MODO TOR ACTIVADO — WebRTC deshabilitado");
        termPrint(bw, "  Usa http:// (sin s) para sitios .onion");
    } else if (mode == "i2p") {
        termPrint(bw, "  MODO I2P ACTIVADO — Proxy HTTP 127.0.0.1:4444");
        termPrint(bw, "  Navega a sitios .i2p normalmente");
    }
    termPrompt(bw);
}

static void disableNetworkMode(BrowserWindow* bw) {
    TabData& td = currentTd(bw);
    if (td.mode == "normal") {
        termPrint(bw, "La pestaña ya está en modo normal.");
        termPrompt(bw);
        return;
    }
    const char* oldUri = webkit_web_view_get_uri(td.webview);
    std::string oldUriStr = oldUri ? oldUri : bw->app->homeUri;

    WebKitWebView* newWv = makeWebview(bw, "normal");
    int idx = bw->currentTab;

    GtkWidget* old = gtk_stack_get_child_by_name(bw->tabStack, ("tab" + std::to_string(idx)).c_str());
    if (old) gtk_stack_remove(bw->tabStack, old);

    td.webview = newWv; td.mode = "normal";
    gtk_stack_add_named(bw->tabStack, GTK_WIDGET(newWv), ("tab" + std::to_string(idx)).c_str());
    gtk_stack_set_visible_child_name(bw->tabStack, ("tab" + std::to_string(idx)).c_str());
    setupDownloadHandler(bw, newWv);
    webkit_web_view_load_uri(newWv, (oldUriStr != "about:blank" ? oldUriStr : bw->app->homeUri).c_str());
    updateBadge(bw, "normal");
    termPrint(bw, "  Modo normal restaurado.");
    termPrompt(bw);
}

// ─── Calculadora segura ─────────────────────────────────────────────────────

static double safeEval(const std::string& expr, bool& ok) {
    // Evaluador muy simple: solo operadores aritméticos básicos y funciones math.h
    // Para una implementación completa se recomienda usar exprtk o tinyexpr.
    // Aquí delegamos en GLib GScanner para parseo básico.
    ok = false;
    // Whitelist de caracteres
    for (char c : expr)
        if (!isdigit(c) && !isspace(c) && c != '+' && c != '-' && c != '*'
            && c != '/' && c != '(' && c != ')' && c != '.' && c != '%'
            && !isalpha(c) && c != '_' && c != '^' && c != ',')
            return 0;
    // Delegar en Python si está disponible (opción simple y segura)
    std::string cmd = "python3 -c \"import math; print(" + expr + ")\" 2>/dev/null";
    FILE* pipe = popen(cmd.c_str(), "r");
    if (!pipe) return 0;
    char buf[128] = {};
    fgets(buf, sizeof(buf), pipe);
    pclose(pipe);
    try {
        double result = std::stod(buf);
        ok = true;
        return result;
    } catch (...) { return 0; }
}

// ─── Comandos de terminal ───────────────────────────────────────────────────

static void runCommand(BrowserWindow* bw, const std::string& raw) {
    size_t sp = raw.find(' ');
    std::string cmd  = strLower(sp != std::string::npos ? raw.substr(0, sp) : raw);
    std::string args = sp != std::string::npos ? raw.substr(sp + 1) : "";
    // Trim args
    while (!args.empty() && isspace(args.front())) args.erase(args.begin());
    while (!args.empty() && isspace(args.back())) args.pop_back();

    auto nav = [&](const std::string& url) {
        webkit_web_view_load_uri(currentWv(bw), url.c_str());
    };

    if (cmd == "help") {
        termPrint(bw,
            "─── Navegación ───────────────────────────────\n"
            "  open <url>            → abre URL en pestaña actual\n"
            "  newtab [url]          → abre nueva pestaña\n"
            "  closetab              → cierra pestaña actual\n"
            "  tab <n>               → cambia a pestaña n (1-based)\n"
            "  back / forward        → historial del navegador\n"
            "  reload / reloadhard   → recarga\n"
            "  home                  → página de inicio\n"
            "  zoom <n>              → nivel de zoom (0.1–5.0)\n"
            "─── Búsqueda ─────────────────────────────────\n"
            "  ddg / google / yt / wiki <consulta>\n"
            "─── Redes alternativas ───────────────────────\n"
            "  tormode / i2pmode / clearnet\n"
            "  loki <dir>   whoami   serverip\n"
            "─── Marcadores e historial ───────────────────\n"
            "  bookmark   bookmarks   history [n]\n"
            "─── Utilidades ───────────────────────────────\n"
            "  dark  calc <expr>  time  date  echo  clear\n"
            "  clearcookies  clearall  about  quit\n"
        );
    } else if (cmd == "open" || cmd == "new") {
        if (!args.empty()) nav(resolveInput(bw, args));
        else termPrint(bw, "Uso: open <url>");
    } else if (cmd == "newtab") {
        openTab(bw, args.empty() ? nullptr : resolveInput(bw, args).c_str(), "normal");
    } else if (cmd == "closetab") {
        onCloseTab(bw, bw->currentTab);
    } else if (cmd == "tab") {
        try { int n = std::stoi(args) - 1; switchTab(bw, n); }
        catch (...) { termPrint(bw, "Uso: tab <número>"); }
    } else if (cmd == "back") {
        if (webkit_web_view_can_go_back(currentWv(bw))) webkit_web_view_go_back(currentWv(bw));
    } else if (cmd == "forward") {
        if (webkit_web_view_can_go_forward(currentWv(bw))) webkit_web_view_go_forward(currentWv(bw));
    } else if (cmd == "reload") {
        webkit_web_view_reload(currentWv(bw));
    } else if (cmd == "reloadhard") {
        webkit_web_view_reload_bypass_cache(currentWv(bw));
    } else if (cmd == "home") {
        nav(bw->app->homeUri);
    } else if (cmd == "zoom") {
        if (!args.empty()) {
            try {
                double level = std::stod(args);
                if (level >= 0.1 && level <= 5.0) {
                    webkit_web_view_set_zoom_level(currentWv(bw), level);
                    termPrint(bw, "Zoom: " + std::to_string(level) + "x");
                } else termPrint(bw, "Zoom válido: 0.1 – 5.0 (1.0 = normal)");
            } catch (...) { termPrint(bw, "Uso: zoom <número>"); }
        } else {
            double lv = webkit_web_view_get_zoom_level(currentWv(bw));
            termPrint(bw, "Zoom actual: " + std::to_string(lv) + "x");
        }
    } else if (cmd == "ddg") {
        nav(args.empty() ? "https://duckduckgo.com" : "https://duckduckgo.com/?q=" + urlEncode(args));
    } else if (cmd == "google") {
        nav(args.empty() ? "https://www.google.com" : "https://www.google.com/search?q=" + urlEncode(args));
    } else if (cmd == "yt") {
        nav(args.empty() ? "https://www.youtube.com" : "https://www.youtube.com/results?search_query=" + urlEncode(args));
    } else if (cmd == "wiki") {
        nav(args.empty() ? "https://es.wikipedia.org" : "https://es.wikipedia.org/wiki/" + urlEncode(args));
    } else if (cmd == "loki") {
        if (!args.empty()) {
            std::string addr = args;
            // Quitar esquema si lo pusieron
            for (const char* pfx : {"https://", "http://"})
                if (startsWith(addr, pfx)) { addr = addr.substr(strlen(pfx)); break; }
            if (!endsWith(addr, ".loki")) addr += ".loki";
            nav("http://" + addr);
        } else termPrint(bw, "Uso: loki <direccion>");
    } else if (cmd == "tormode") {
        enableNetworkMode(bw, "tor"); return;
    } else if (cmd == "i2pmode") {
        enableNetworkMode(bw, "i2p"); return;
    } else if (cmd == "clearnet") {
        disableNetworkMode(bw); return;
    } else if (cmd == "whoami") {
        termPrint(bw, "Consultando IP pública...");
        // Usamos GLib spawn para no bloquear
        char* argv[] = { (char*)"curl", (char*)"-s", (char*)"--max-time", (char*)"7", (char*)"https://api.ipify.org", nullptr };
        GPid pid; gint out_fd;
        GError* err = nullptr;
        if (g_spawn_async_with_pipes(nullptr, argv, nullptr,
                G_SPAWN_SEARCH_PATH, nullptr, nullptr,
                &pid, nullptr, &out_fd, nullptr, &err)) {
            GIOChannel* ch = g_io_channel_unix_new(out_fd);
            g_io_add_watch(ch, G_IO_IN, [](GIOChannel* c, GIOCondition, gpointer p) -> gboolean {
                auto* bw2 = static_cast<BrowserWindow*>(p);
                gchar* line = nullptr;
                gsize len = 0;
                g_io_channel_read_line(c, &line, &len, nullptr, nullptr);
                if (line) {
                    std::string ip(line, len);
                    while (!ip.empty() && isspace(ip.back())) ip.pop_back();
                    termPrint(bw2, "IP pública: " + ip);
                    g_free(line);
                }
                termPrint(bw2, ""); termPrompt(bw2);
                return FALSE;
            }, bw);
            g_io_channel_unref(ch);
        } else {
            termPrint(bw, "Error ejecutando curl.");
            if (err) g_error_free(err);
        }
        return;
    } else if (cmd == "bookmark") {
        const char* uri = webkit_web_view_get_uri(currentWv(bw));
        if (!uri || std::string(uri) == "about:blank") {
            termPrint(bw, "Sin página activa.");
        } else {
            const char* titleRaw = webkit_web_view_get_title(currentWv(bw));
            std::string title = titleRaw ? titleRaw : uri;
            if (bw->app->isBookmarked(uri)) {
                bw->app->removeBookmark(uri);
                termPrint(bw, "Marcador eliminado: " + std::string(uri));
                gtk_button_set_label(bw->bookmarkStar, "☆");
            } else {
                bw->app->addBookmark(uri, title);
                termPrint(bw, "Marcador guardado: " + title);
                gtk_button_set_label(bw->bookmarkStar, "★");
            }
        }
    } else if (cmd == "bookmarks") {
        if (bw->app->bookmarks.empty()) { termPrint(bw, "Sin marcadores guardados."); }
        else {
            termPrint(bw, "Marcadores guardados:");
            int i = 1;
            for (const auto& b : bw->app->bookmarks)
                termPrint(bw, "  " + std::to_string(i++) + ". " +
                    b["title"].get<std::string>() + "\n       " + b["url"].get<std::string>());
        }
    } else if (cmd == "history") {
        int n = 10;
        try { if (!args.empty()) n = std::stoi(args); } catch (...) {}
        if (bw->app->history.empty()) { termPrint(bw, "El historial está vacío."); }
        else {
            termPrint(bw, "Últimas " + std::to_string(n) + " páginas:");
            int total = (int)bw->app->history.size();
            int start = std::max(0, total - n);
            int i = 1;
            for (int j = total - 1; j >= start; j--) {
                const auto& h = bw->app->history[j];
                std::string ts = h["ts"].get<std::string>().substr(0, 19);
                std::replace(ts.begin(), ts.end(), 'T', ' ');
                termPrint(bw, "  " + std::to_string(i++) + ". [" + ts + "] " +
                    h["title"].get<std::string>() + "\n       " + h["url"].get<std::string>());
            }
        }
    } else if (cmd == "dark") {
        bw->app->darkMode = !bw->app->darkMode;
        termPrint(bw, std::string("Modo oscuro ") + (bw->app->darkMode ? "activado" : "desactivado") + ".");
        if (bw->app->darkMode) applyDarkCss(bw);
    } else if (cmd == "calc") {
        if (!args.empty()) {
            bool ok;
            double result = safeEval(args, ok);
            termPrint(bw, ok ? (args + " = " + std::to_string(result)) : "Error en la expresión.");
        } else termPrint(bw, "Uso: calc <expresión>");
    } else if (cmd == "time") {
        time_t t = time(nullptr); struct tm* tm = localtime(&t); char buf[16];
        strftime(buf, sizeof(buf), "%H:%M:%S", tm); termPrint(bw, buf);
    } else if (cmd == "date") {
        time_t t = time(nullptr); struct tm* tm = localtime(&t); char buf[16];
        strftime(buf, sizeof(buf), "%Y-%m-%d", tm); termPrint(bw, buf);
    } else if (cmd == "echo") {
        if (!args.empty()) termPrint(bw, args);
    } else if (cmd == "clear" || cmd == "clean") {
        gtk_text_buffer_set_text(bw->terminalBuf, "", -1);
    } else if (cmd == "about") {
        termPrint(bw,
            "PrekT-BR v2.1 — Hardened Edition\n"
            "WebKitGTK 6 + GTK 4 + C++20\n"
            "Redes: Tor (SOCKS5 :9050), I2P (HTTP :4444)\n"
            "─── Protecciones activas ──────────────────────\n"
            "  [*] WebRTC, popups, autoplay bloqueados\n"
            "  [*] User-Agent: Firefox/Windows normalizado\n"
            "  [*] Letterboxing, timing, canvas, audio\n"
            "  [*] Navigator, Screen, WebGL normalizados\n"
            "  [*] Historial/marcadores: cifrados (PBKDF2+XOR)\n"
        );
    } else if (cmd == "clearcookies") {
        clearTabData(bw, currentTd(bw));
        termPrint(bw, "Cookies y datos de sesión de la pestaña actual eliminados.");
    } else if (cmd == "clearall") {
        for (auto& td : bw->tabs) clearTabData(bw, td);
        termPrint(bw, "Datos de todas las pestañas eliminados.");
    } else if (cmd == "quit" || cmd == "exit") {
        g_application_quit(g_application_get_default());
        return;
    } else {
        termPrint(bw, "Comando desconocido: '" + cmd + "'  —  escribe 'help'");
    }

    termPrint(bw, "");
    termPrompt(bw);
}

// ─── Manejo de teclado en terminal ─────────────────────────────────────────

static gboolean onTerminalKey(GtkEventControllerKey* ctrl, guint keyval,
                              guint, GdkModifierType, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    if (keyval == GDK_KEY_Return || keyval == GDK_KEY_KP_Enter) {
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(bw->terminalBuf, &start);
        gtk_text_buffer_get_end_iter(bw->terminalBuf,   &end);
        gchar* full = gtk_text_buffer_get_text(bw->terminalBuf, &start, &end, FALSE);
        std::string text(full);
        g_free(full);
        // Trim trailing newline
        while (!text.empty() && (text.back() == '\n' || text.back() == '\r')) text.pop_back();
        // Obtener última línea
        size_t nl = text.rfind('\n');
        std::string last = nl != std::string::npos ? text.substr(nl + 1) : text;
        // Trim
        while (!last.empty() && isspace(last.front())) last.erase(last.begin());
        if (startsWith(last, "> ")) {
            std::string cmd = last.substr(2);
            while (!cmd.empty() && isspace(cmd.front())) cmd.erase(cmd.begin());
            while (!cmd.empty() && isspace(cmd.back())) cmd.pop_back();
            if (!cmd.empty()) {
                termPrint(bw, "");
                runCommand(bw, cmd);
                return TRUE;
            }
        }
        termPrint(bw, ""); termPrompt(bw);
        return TRUE;
    }
    // Proteger prompt
    static const guint protectedKeys[] = {
        GDK_KEY_BackSpace, GDK_KEY_Delete, GDK_KEY_Left, GDK_KEY_Home,
        GDK_KEY_KP_Left,   GDK_KEY_KP_Home, 0
    };
    for (int i = 0; protectedKeys[i]; i++) {
        if (keyval == protectedKeys[i] && bw->promptEndMark) {
            GtkTextMark* insertMark = gtk_text_buffer_get_insert(bw->terminalBuf);
            GtkTextIter cursor, limit;
            gtk_text_buffer_get_iter_at_mark(bw->terminalBuf, &cursor, insertMark);
            gtk_text_buffer_get_iter_at_mark(bw->terminalBuf, &limit,  bw->promptEndMark);
            if (gtk_text_iter_compare(&cursor, &limit) <= 0) return TRUE;
        }
    }
    return FALSE;
}

// ─── Manejo de teclado en inspector ────────────────────────────────────────

static void closeInspector(BrowserWindow* bw);
static void inspectorApply(BrowserWindow* bw);

static gboolean onInspectorKey(GtkEventControllerKey*, guint keyval, guint,
                                GdkModifierType state, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    bool ctrl = !!(state & GDK_CONTROL_MASK);
    if (ctrl && keyval == GDK_KEY_Return) { inspectorApply(bw); return TRUE; }
    if (keyval == GDK_KEY_Escape)          { closeInspector(bw); return TRUE; }
    return FALSE;
}

// ─── Inspector ──────────────────────────────────────────────────────────────

static void inspectorLoad(BrowserWindow* bw);

static void openInspector(BrowserWindow* bw) {
    if (bw->inspectorMode) return;
    if (bw->terminalVisible) {
        gtk_label_set_text(bw->statusbar, "Cierra la terminal primero (Ctrl+Alt+T)");
        g_timeout_add(2000, [](gpointer p) -> gboolean { gtk_label_set_text(GTK_LABEL(p), ""); return FALSE; }, bw->statusbar);
        return;
    }
    bw->inspectorMode = true;
    gtk_box_append(bw->contentArea, bw->inspPanel);
    inspectorLoad(bw);
}

static void closeInspector(BrowserWindow* bw) {
    if (!bw->inspectorMode) return;
    gtk_box_remove(bw->contentArea, bw->inspPanel);
    bw->inspectorMode = false;
}

static void inspectorApply(BrowserWindow* bw) {
    GtkTextIter start, end;
    gtk_text_buffer_get_start_iter(bw->inspectorBuf, &start);
    gtk_text_buffer_get_end_iter(bw->inspectorBuf,   &end);
    gchar* html = gtk_text_buffer_get_text(bw->inspectorBuf, &start, &end, FALSE);
    std::string js = std::string("document.open();document.write(`") +
                     html + "`);document.close();";
    g_free(html);
    webkit_web_view_evaluate_javascript(currentWv(bw), js.c_str(), -1,
        nullptr, nullptr, nullptr, nullptr, nullptr);
}

static void inspectorLoad(BrowserWindow* bw) {
    gtk_text_buffer_set_text(bw->inspectorBuf, "Cargando HTML…", -1);
    WebKitWebView* wv = currentWv(bw);
    struct Ctx { GtkTextBuffer* buf; };
    auto* ctx = new Ctx{bw->inspectorBuf};
    webkit_web_view_evaluate_javascript(wv, "document.documentElement.outerHTML", -1,
        nullptr, nullptr, nullptr,
        [](GObject* src, GAsyncResult* res, gpointer p) {
            auto* ctx2 = static_cast<Ctx*>(p);
            GError* err = nullptr;
            // En WebKit6 evaluate_javascript_finish devuelve JSCValue* directamente
            JSCValue* val = webkit_web_view_evaluate_javascript_finish(
                WEBKIT_WEB_VIEW(src), res, &err);
            if (val) {
                char* str = jsc_value_to_string(val);
                gtk_text_buffer_set_text(ctx2->buf, str ? str : "[vacío]", -1);
                g_free(str);
                g_object_unref(val);
            } else {
                std::string msg = err ? std::string("[Error: ") + err->message + "]" : "[vacío]";
                gtk_text_buffer_set_text(ctx2->buf, msg.c_str(), -1);
                if (err) g_error_free(err);
            }
            delete ctx2;
        }, ctx);
}

// ─── Atajo de teclado global ────────────────────────────────────────────────

static void toggleFindbar(BrowserWindow* bw);
static void toggleTerminal(BrowserWindow* bw);
static void toggleInspector(BrowserWindow* bw);

static gboolean onGlobalKey(GtkEventControllerKey*, guint keyval, guint,
                             GdkModifierType state, gpointer data) {
    auto* bw = static_cast<BrowserWindow*>(data);
    bool ctrlHeld  = !!(state & GDK_CONTROL_MASK);
    bool altHeld   = !!(state & GDK_ALT_MASK);
    bool shiftHeld = !!(state & GDK_SHIFT_MASK);

    if (ctrlHeld && !altHeld) {
        if (keyval == GDK_KEY_t) { openTab(bw); return TRUE; }
        if (keyval == GDK_KEY_w) { onCloseTab(bw, bw->currentTab); return TRUE; }
        if (keyval == GDK_KEY_l) { gtk_widget_grab_focus(GTK_WIDGET(bw->urlEntry)); gtk_editable_select_region(GTK_EDITABLE(bw->urlEntry), 0, -1); return TRUE; }
        if (keyval == GDK_KEY_r && !shiftHeld) { webkit_web_view_reload(currentWv(bw)); return TRUE; }
        if (keyval == GDK_KEY_r &&  shiftHeld) { webkit_web_view_reload_bypass_cache(currentWv(bw)); return TRUE; }
        if (keyval == GDK_KEY_f) { toggleFindbar(bw); return TRUE; }
        if (keyval == GDK_KEY_plus || keyval == GDK_KEY_equal) {
            double z = webkit_web_view_get_zoom_level(currentWv(bw));
            webkit_web_view_set_zoom_level(currentWv(bw), std::min(z + 0.1, 5.0)); return TRUE;
        }
        if (keyval == GDK_KEY_minus) {
            double z = webkit_web_view_get_zoom_level(currentWv(bw));
            webkit_web_view_set_zoom_level(currentWv(bw), std::max(z - 0.1, 0.1)); return TRUE;
        }
        if (keyval == GDK_KEY_0) { webkit_web_view_set_zoom_level(currentWv(bw), 1.0); return TRUE; }
    }
    if (ctrlHeld && altHeld) {
        if (keyval == GDK_KEY_t || keyval == GDK_KEY_Return) { toggleTerminal(bw); return TRUE; }
    }
    if (!ctrlHeld && !altHeld) {
        if (keyval == GDK_KEY_Escape) {
            if (bw->findbarVisible) { closeFindbar(bw); return TRUE; }
            if (bw->inspectorMode)  { closeInspector(bw); return TRUE; }
        }
    }
    if (altHeld && !ctrlHeld) {
        if (keyval == GDK_KEY_Left  && webkit_web_view_can_go_back(currentWv(bw)))    { webkit_web_view_go_back(currentWv(bw));    return TRUE; }
        if (keyval == GDK_KEY_Right && webkit_web_view_can_go_forward(currentWv(bw))) { webkit_web_view_go_forward(currentWv(bw)); return TRUE; }
    }
    return FALSE;
}

static void toggleFindbar(BrowserWindow* bw) {
    if (bw->findbarVisible) closeFindbar(bw);
    else { gtk_widget_set_visible(GTK_WIDGET(bw->findbarBox), TRUE); bw->findbarVisible = true; gtk_widget_grab_focus(GTK_WIDGET(bw->findEntry)); }
}

static void toggleTerminal(BrowserWindow* bw) {
    if (bw->inspectorMode) {
        gtk_label_set_text(bw->statusbar, "Cierra el inspector primero (Esc)");
        g_timeout_add(2000, [](gpointer p) -> gboolean { gtk_label_set_text(GTK_LABEL(p), ""); return FALSE; }, bw->statusbar);
        return;
    }
    if (bw->terminalVisible) {
        gtk_box_remove(bw->contentArea, GTK_WIDGET(bw->termScroll));
        bw->terminalVisible = false;
    } else {
        gtk_box_append(bw->contentArea, GTK_WIDGET(bw->termScroll));
        bw->terminalVisible = true;
        gtk_widget_grab_focus(GTK_WIDGET(bw->terminalTv));
    }
}

static void toggleInspector(BrowserWindow* bw) {
    if (bw->inspectorMode) closeInspector(bw);
    else openInspector(bw);
}

// ─── Construcción de la ventana ─────────────────────────────────────────────

static BrowserWindow* buildWindow(GtkApplication* gapp, AppData* app) {
    auto* bw = new BrowserWindow();
    bw->app = app;
    g_bw = bw;

    bw->window = GTK_APPLICATION_WINDOW(gtk_application_window_new(gapp));
    gtk_window_set_title(GTK_WINDOW(bw->window), "PrekT-BR");
    gtk_window_set_default_size(GTK_WINDOW(bw->window), 1280, 800);

    GtkBox* root = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 0));

    // Barra de pestañas
    bw->tabbarBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2));
    gtk_widget_add_css_class(GTK_WIDGET(bw->tabbarBox), "tabbar");

    GtkButton* newTabBtn = GTK_BUTTON(gtk_button_new_with_label("+"));
    gtk_widget_add_css_class(GTK_WIDGET(newTabBtn), "new-tab-btn");
    gtk_widget_set_tooltip_text(GTK_WIDGET(newTabBtn), "Nueva pestaña");
    g_signal_connect(newTabBtn, "clicked", G_CALLBACK(+[](GtkButton*, gpointer p) { openTab(static_cast<BrowserWindow*>(p)); }), bw);

    GtkScrolledWindow* tabbarScroll = GTK_SCROLLED_WINDOW(gtk_scrolled_window_new());
    gtk_scrolled_window_set_policy(tabbarScroll, GTK_POLICY_AUTOMATIC, GTK_POLICY_NEVER);
    gtk_widget_set_hexpand(GTK_WIDGET(tabbarScroll), TRUE);
    gtk_scrolled_window_set_child(tabbarScroll, GTK_WIDGET(bw->tabbarBox));
    gtk_scrolled_window_set_min_content_height(tabbarScroll, 38);

    GtkBox* tabbarRow = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0));
    gtk_widget_add_css_class(GTK_WIDGET(tabbarRow), "tabbar");
    gtk_box_append(tabbarRow, GTK_WIDGET(tabbarScroll));
    gtk_box_append(tabbarRow, GTK_WIDGET(newTabBtn));

    // Barra de navegación
    bw->backBtn    = makeNavBtn("←", "Atrás (Alt+Izq)",    G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); if (webkit_web_view_can_go_back(currentWv(b))) webkit_web_view_go_back(currentWv(b)); }), bw);
    bw->forwardBtn = makeNavBtn("→", "Adelante (Alt+Der)",  G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); if (webkit_web_view_can_go_forward(currentWv(b))) webkit_web_view_go_forward(currentWv(b)); }), bw);
    bw->reloadBtn  = makeNavBtn("↻", "Recargar (Ctrl+R)",   G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); if (webkit_web_view_is_loading(currentWv(b))) webkit_web_view_stop_loading(currentWv(b)); else webkit_web_view_reload(currentWv(b)); }), bw);
    makeNavBtn("⌂", "Ir al inicio", G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); webkit_web_view_load_uri(currentWv(b), b->app->homeUri.c_str()); }), bw);

    bw->bookmarkStar = makeNavBtn("★", "Guardar/quitar marcador", G_CALLBACK(+[](GtkButton*, gpointer p) {
        auto* bw2 = static_cast<BrowserWindow*>(p);
        const char* uri = webkit_web_view_get_uri(currentWv(bw2));
        if (!uri || std::string(uri) == "about:blank") return;
        const char* t = webkit_web_view_get_title(currentWv(bw2));
        if (bw2->app->isBookmarked(uri)) {
            bw2->app->removeBookmark(uri); gtk_button_set_label(bw2->bookmarkStar, "☆");
            gtk_label_set_text(bw2->statusbar, "Marcador eliminado");
        } else {
            bw2->app->addBookmark(uri, t ? t : uri); gtk_button_set_label(bw2->bookmarkStar, "★");
            gtk_label_set_text(bw2->statusbar, "Marcador guardado");
        }
        g_timeout_add(2000, [](gpointer q) -> gboolean { gtk_label_set_text(GTK_LABEL(q), ""); return FALSE; }, bw2->statusbar);
        // Refrescar sidebar si está mostrando marcadores
        if (bw2->sidebarMode == "bookmarks") showSidebar(bw2, "bookmarks");
    }), bw);

    bw->urlEntry = GTK_ENTRY(gtk_entry_new());
    gtk_widget_set_hexpand(GTK_WIDGET(bw->urlEntry), TRUE);
    gtk_widget_add_css_class(GTK_WIDGET(bw->urlEntry), "url-entry");
    gtk_entry_set_placeholder_text(bw->urlEntry, "Ingresa una URL o busca en DuckDuckGo...");
    g_signal_connect(bw->urlEntry, "activate", G_CALLBACK(+[](GtkEntry* e, gpointer p) {
        auto* bw2 = static_cast<BrowserWindow*>(p);
        const char* txt = gtk_editable_get_text(GTK_EDITABLE(e));
        if (txt && txt[0]) webkit_web_view_load_uri(currentWv(bw2), resolveInput(bw2, txt).c_str());
    }), bw);

    bw->badge = GTK_LABEL(gtk_label_new(""));
    gtk_widget_add_css_class(GTK_WIDGET(bw->badge), "badge-normal");
    gtk_widget_set_tooltip_text(GTK_WIDGET(bw->badge), "Modo de red actual");
    gtk_widget_set_visible(GTK_WIDGET(bw->badge), FALSE);

    bw->secBadge = GTK_LABEL(gtk_label_new(""));
    gtk_widget_set_tooltip_text(GTK_WIDGET(bw->secBadge), "Estado de seguridad");
    gtk_widget_set_visible(GTK_WIDGET(bw->secBadge), FALSE);

    GtkButton* bmarksBtn  = makeNavBtn("\u2318",          "Marcadores",               G_CALLBACK(+[](GtkButton*, gpointer p) { toggleSidebar(static_cast<BrowserWindow*>(p), "bookmarks"); }), bw);
    GtkButton* historyBtn2= makeNavBtn("\U0001F552\uFE0E","Historial",                G_CALLBACK(+[](GtkButton*, gpointer p) { toggleSidebar(static_cast<BrowserWindow*>(p), "history");   }), bw);
    GtkButton* termBtn    = makeNavBtn(">_", "Terminal (Ctrl+Alt+T)",     G_CALLBACK(+[](GtkButton*, gpointer p) { toggleTerminal(static_cast<BrowserWindow*>(p)); }), bw);
    GtkButton* findBtn2   = makeNavBtn("\u2315",  "Buscar en página (Ctrl+F)", G_CALLBACK(+[](GtkButton*, gpointer p) { toggleFindbar(static_cast<BrowserWindow*>(p)); }), bw);
    GtkButton* inspBtn    = makeNavBtn("</>", "Inspector HTML",            G_CALLBACK(+[](GtkButton*, gpointer p) { toggleInspector(static_cast<BrowserWindow*>(p)); }), bw);

    GtkBox* navBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4));
    gtk_widget_add_css_class(GTK_WIDGET(navBox), "toolbar");
    for (GtkWidget* w : {GTK_WIDGET(bw->backBtn), GTK_WIDGET(bw->forwardBtn), GTK_WIDGET(bw->reloadBtn),
                          GTK_WIDGET(bw->secBadge), GTK_WIDGET(bw->urlEntry), GTK_WIDGET(bw->bookmarkStar),
                          GTK_WIDGET(bw->badge), GTK_WIDGET(bmarksBtn), GTK_WIDGET(historyBtn2),
                          GTK_WIDGET(termBtn), GTK_WIDGET(findBtn2), GTK_WIDGET(inspBtn)})
        gtk_box_append(navBox, w);

    // Área de contenido
    bw->contentArea = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0));
    gtk_widget_set_vexpand(GTK_WIDGET(bw->contentArea), TRUE);
    gtk_widget_set_hexpand(GTK_WIDGET(bw->contentArea), TRUE);

    bw->tabStack = GTK_STACK(gtk_stack_new());
    gtk_widget_set_vexpand(GTK_WIDGET(bw->tabStack), TRUE);
    gtk_widget_set_hexpand(GTK_WIDGET(bw->tabStack), TRUE);
    gtk_box_append(bw->contentArea, GTK_WIDGET(bw->tabStack));

    // Terminal — se necesita g_object_ref para sobrevivir a gtk_box_remove
    bw->terminalBuf = gtk_text_buffer_new(nullptr);
    bw->terminalTv  = GTK_TEXT_VIEW(gtk_text_view_new_with_buffer(bw->terminalBuf));
    gtk_text_view_set_editable(bw->terminalTv, TRUE);
    gtk_text_view_set_cursor_visible(bw->terminalTv, TRUE);
    gtk_text_view_set_wrap_mode(bw->terminalTv, GTK_WRAP_WORD_CHAR);
    gtk_text_view_set_monospace(bw->terminalTv, TRUE);
    gtk_widget_add_css_class(GTK_WIDGET(bw->terminalTv), "terminal");
    gtk_widget_set_size_request(GTK_WIDGET(bw->terminalTv), 340, 200);

    bw->termScroll = GTK_SCROLLED_WINDOW(gtk_scrolled_window_new());
    gtk_widget_set_vexpand(GTK_WIDGET(bw->termScroll), TRUE);
    gtk_scrolled_window_set_min_content_width(bw->termScroll, 340);
    gtk_scrolled_window_set_min_content_height(bw->termScroll, 200);
    gtk_scrolled_window_set_child(bw->termScroll, GTK_WIDGET(bw->terminalTv));
    // Mantener vivo cuando se remueve del box
    g_object_ref(bw->termScroll);

    GtkEventControllerKey* termKey = GTK_EVENT_CONTROLLER_KEY(gtk_event_controller_key_new());
    g_signal_connect(termKey, "key-pressed", G_CALLBACK(onTerminalKey), bw);
    gtk_widget_add_controller(GTK_WIDGET(bw->terminalTv), GTK_EVENT_CONTROLLER(termKey));

    // Inspector
    bw->inspectorBuf = gtk_text_buffer_new(nullptr);
    bw->inspectorTv  = GTK_TEXT_VIEW(gtk_text_view_new_with_buffer(bw->inspectorBuf));
    gtk_text_view_set_editable(bw->inspectorTv, TRUE);
    gtk_text_view_set_cursor_visible(bw->inspectorTv, TRUE);
    gtk_text_view_set_wrap_mode(bw->inspectorTv, GTK_WRAP_WORD_CHAR);
    gtk_text_view_set_monospace(bw->inspectorTv, TRUE);
    gtk_widget_add_css_class(GTK_WIDGET(bw->inspectorTv), "inspector-tv");
    gtk_widget_set_size_request(GTK_WIDGET(bw->inspectorTv), 400, 200);

    GtkScrolledWindow* inspScroll = GTK_SCROLLED_WINDOW(gtk_scrolled_window_new());
    gtk_widget_set_vexpand(GTK_WIDGET(inspScroll), TRUE);
    gtk_scrolled_window_set_min_content_width(inspScroll, 400);
    gtk_scrolled_window_set_min_content_height(inspScroll, 200);
    gtk_scrolled_window_set_child(inspScroll, GTK_WIDGET(bw->inspectorTv));

    GtkBox* inspBtnBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4));
    gtk_widget_add_css_class(GTK_WIDGET(inspBtnBox), "toolbar");
    gtk_box_append(inspBtnBox, GTK_WIDGET(makeNavBtn("Cargar HTML", "Obtener HTML", G_CALLBACK(+[](GtkButton*, gpointer p) { inspectorLoad(static_cast<BrowserWindow*>(p)); }), bw)));
    gtk_box_append(inspBtnBox, GTK_WIDGET(makeNavBtn("Aplicar",     "Aplicar HTML", G_CALLBACK(+[](GtkButton*, gpointer p) { inspectorApply(static_cast<BrowserWindow*>(p)); }), bw)));
    gtk_box_append(inspBtnBox, GTK_WIDGET(makeNavBtn("Cerrar",      "Cerrar",       G_CALLBACK(+[](GtkButton*, gpointer p) { closeInspector(static_cast<BrowserWindow*>(p)); }), bw)));

    GtkBox* inspPanel = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 0));
    gtk_box_append(inspPanel, GTK_WIDGET(inspBtnBox));
    gtk_box_append(inspPanel, GTK_WIDGET(inspScroll));
    bw->inspPanel = GTK_WIDGET(inspPanel);
    // Mantener vivo cuando se remueve del box
    g_object_ref(bw->inspPanel);

    GtkEventControllerKey* inspKey = GTK_EVENT_CONTROLLER_KEY(gtk_event_controller_key_new());
    g_signal_connect(inspKey, "key-pressed", G_CALLBACK(onInspectorKey), bw);
    gtk_widget_add_controller(GTK_WIDGET(bw->inspectorTv), GTK_EVENT_CONTROLLER(inspKey));

    // Findbar
    bw->findbarBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6));
    gtk_widget_add_css_class(GTK_WIDGET(bw->findbarBox), "findbar");
    bw->findEntry = GTK_ENTRY(gtk_entry_new());
    gtk_widget_add_css_class(GTK_WIDGET(bw->findEntry), "findbar-entry");
    gtk_entry_set_placeholder_text(bw->findEntry, "Buscar en página…");
    g_signal_connect(bw->findEntry, "activate", G_CALLBACK(+[](GtkEntry*, gpointer p) {
        auto* bw2 = static_cast<BrowserWindow*>(p);
        const char* t = gtk_editable_get_text(GTK_EDITABLE(bw2->findEntry));
        if (t && t[0]) webkit_find_controller_search_next(webkit_web_view_get_find_controller(currentWv(bw2)));
    }), bw);
    g_signal_connect(bw->findEntry, "changed", G_CALLBACK(+[](GtkEntry*, gpointer p) { findChanged(static_cast<BrowserWindow*>(p)); }), bw);
    bw->findLabel = GTK_LABEL(gtk_label_new(""));
    gtk_widget_add_css_class(GTK_WIDGET(bw->findLabel), "findbar-label");
    gtk_box_append(bw->findbarBox, GTK_WIDGET(bw->findEntry));
    gtk_box_append(bw->findbarBox, GTK_WIDGET(makeNavBtn("↑", "Anterior", G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); const char* t = gtk_editable_get_text(GTK_EDITABLE(b->findEntry)); if (t && t[0]) webkit_find_controller_search_previous(webkit_web_view_get_find_controller(currentWv(b))); }), bw)));
    gtk_box_append(bw->findbarBox, GTK_WIDGET(makeNavBtn("↓", "Siguiente", G_CALLBACK(+[](GtkButton*, gpointer p) { auto* b = static_cast<BrowserWindow*>(p); const char* t = gtk_editable_get_text(GTK_EDITABLE(b->findEntry)); if (t && t[0]) webkit_find_controller_search_next(webkit_web_view_get_find_controller(currentWv(b))); }), bw)));
    gtk_box_append(bw->findbarBox, GTK_WIDGET(bw->findLabel));
    gtk_box_append(bw->findbarBox, GTK_WIDGET(makeNavBtn("✕", "Cerrar (Esc)", G_CALLBACK(+[](GtkButton*, gpointer p) { closeFindbar(static_cast<BrowserWindow*>(p)); }), bw)));

    // Barra de estado
    bw->statusbar = GTK_LABEL(gtk_label_new(""));
    gtk_widget_add_css_class(GTK_WIDGET(bw->statusbar), "statusbar");
    gtk_label_set_xalign(bw->statusbar, 0.0f);
    gtk_widget_set_hexpand(GTK_WIDGET(bw->statusbar), TRUE);
    gtk_label_set_ellipsize(bw->statusbar, PANGO_ELLIPSIZE_END);

    bw->dlProgress = GTK_PROGRESS_BAR(gtk_progress_bar_new());
    gtk_widget_add_css_class(GTK_WIDGET(bw->dlProgress), "dl-progress");
    gtk_widget_set_visible(GTK_WIDGET(bw->dlProgress), FALSE);
    gtk_widget_set_valign(GTK_WIDGET(bw->dlProgress), GTK_ALIGN_CENTER);
    gtk_widget_set_size_request(GTK_WIDGET(bw->dlProgress), 150, -1);

    GtkBox* statusbarBox = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8));
    gtk_widget_add_css_class(GTK_WIDGET(statusbarBox), "statusbar");
    gtk_box_append(statusbarBox, GTK_WIDGET(bw->statusbar));
    gtk_box_append(statusbarBox, GTK_WIDGET(bw->dlProgress));

    gtk_box_append(root, GTK_WIDGET(tabbarRow));
    gtk_box_append(root, GTK_WIDGET(navBox));
    gtk_box_append(root, GTK_WIDGET(bw->contentArea));
    gtk_box_append(root, GTK_WIDGET(bw->findbarBox));
    gtk_box_append(root, GTK_WIDGET(statusbarBox));
    gtk_window_set_child(GTK_WINDOW(bw->window), GTK_WIDGET(root));
    gtk_widget_set_visible(GTK_WIDGET(bw->findbarBox), FALSE);

    // Atajos globales
    GtkEventControllerKey* globalKey = GTK_EVENT_CONTROLLER_KEY(gtk_event_controller_key_new());
    g_signal_connect(globalKey, "key-pressed", G_CALLBACK(onGlobalKey), bw);
    gtk_widget_add_controller(GTK_WIDGET(bw->window), GTK_EVENT_CONTROLLER(globalKey));

    termPrint(bw, "PrekT-BR v2.1  —  escribe 'help' para ver los comandos");
    termPrompt(bw);

    return bw;
}

// ─── Callbacks de la GtkApplication ────────────────────────────────────────

static void onActivate(GtkApplication* app, gpointer) {
    // Inicializar clave maestra
    initMasterKey();

    // Crear directorio de datos
    g_mkdir_with_parents(dataDir().c_str(), 0700);

    // Cargar CSS
    GtkCssProvider* provider = gtk_css_provider_new();
    gtk_css_provider_load_from_string(provider, GLOBAL_CSS);
    gtk_style_context_add_provider_for_display(
        gdk_display_get_default(), GTK_STYLE_PROVIDER(provider),
        GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    g_object_unref(provider);

    // Inicializar datos de la app
    std::string cwd = g_get_current_dir();
    g_app.homeUri   = "file://" + cwd + "/newtab.html";
    g_app.history   = loadJson(historyFile(),   json::array());
    g_app.bookmarks = loadJson(bookmarksFile(), json::array());

    // Construir y mostrar ventana
    BrowserWindow* bw = buildWindow(app, &g_app);
    openTab(bw, g_app.homeUri.c_str());
    gtk_window_present(GTK_WINDOW(bw->window));
}

// ─── Punto de entrada ───────────────────────────────────────────────────────

int main(int argc, char** argv) {
    // Configuración de entorno
    g_setenv("GDK_DEBUG", "portals", FALSE);
    g_setenv("GTK_A11Y", "none", FALSE);

    GtkApplication* app = gtk_application_new(
        "com.cinnamolhyia.prektbr",
        G_APPLICATION_DEFAULT_FLAGS
    );
    g_signal_connect(app, "activate", G_CALLBACK(onActivate), nullptr);

    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    return status;
}
