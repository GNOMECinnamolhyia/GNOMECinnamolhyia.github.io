#!/usr/bin/env gjs
// -*- mode: js; js-indent-level: 4 -*-
//
//  PrekT-BR — Navegador personal basado en WebKitGTK 6
//  Versión 2.1 - SECURE ENHANCED (GJS port)
//

import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk?version=4.0';
import Gdk from 'gi://Gdk?version=4.0';
import WebKit from 'gi://WebKit?version=6.0';

// ─── Rutas de datos ────────────────────────────────────────────────────────

const DATA_DIR      = GLib.build_filenamev([GLib.get_home_dir(), '.local', 'share', 'prektbr']);
const HISTORY_FILE  = GLib.build_filenamev([DATA_DIR, 'history.json']);
const BOOKMARKS_FILE= GLib.build_filenamev([DATA_DIR, 'bookmarks.json']);
const SALT_FILE     = GLib.build_filenamev([DATA_DIR, '.salt']);

GLib.mkdir_with_parents(DATA_DIR, 0o700);

// ─── Cifrado XOR con clave PBKDF2 ─────────────────────────────────────────

function getOrCreateSalt() {
    try {
        const [ok, data] = GLib.file_get_contents(SALT_FILE);
        if (ok && data.length === 32) return Array.from(data);
    } catch (_) {}
    // Generar sal aleatoria de 32 bytes
    const salt = Array.from({ length: 32 }, () => Math.floor(Math.random() * 256));
    try {
        GLib.file_set_contents(SALT_FILE, new Uint8Array(salt));
    } catch (_) {}
    return salt;
}

// Derivación de clave usando GLib SHA-256 encadenado.
// Usa solo strings hex (ASCII puro) para evitar problemas de encoding con bytes binarios.
function deriveKey(length = 64) {
    const user = GLib.get_user_name() || 'prektbr';
    const salt = getOrCreateSalt();
    // Representar la sal como string hex para que sea ASCII puro
    const saltHex = salt.map(b => b.toString(16).padStart(2, '0')).join('');
    const baseInput = `${user}prektbr-v3${saltHex}`;

    // Iteraciones PBKDF2-simuladas: encadenamos SHA-256 sobre strings hex
    let current = baseInput;
    const ITERS = 200000;
    const BATCH = 5000; // más rápido que 1 por 1
    for (let i = 0; i < ITERS; i += BATCH) {
        const cs = GLib.Checksum.new(GLib.ChecksumType.SHA256);
        // update acepta Uint8Array; usamos TextEncoder que es seguro aquí porque current es ASCII hex
        const bytes = new TextEncoder().encode(current);
        cs.update(bytes, bytes.length);
        current = cs.get_string(); // string hex de 64 chars (SHA-256)
    }

    // Expandir a `length` bytes: cada ronda produce 32 bytes (64 hex chars)
    const key = new Uint8Array(length);
    let pos = 0;
    let counter = 0;
    while (pos < length) {
        const cs = GLib.Checksum.new(GLib.ChecksumType.SHA256);
        const input = new TextEncoder().encode(current + counter.toString());
        cs.update(input, input.length);
        const hex = cs.get_string(); // 64 hex chars = 32 bytes
        // Convertir hex a bytes
        for (let i = 0; i + 1 < hex.length && pos < length; i += 2, pos++) {
            key[pos] = parseInt(hex.slice(i, i + 2), 16);
        }
        counter++;
    }
    return key;
}

const _KEY = deriveKey();

function xorBytes(data) {
    // data puede ser Uint8Array o Array<number>
    const arr = data instanceof Uint8Array ? data : new Uint8Array(data);
    const out = new Uint8Array(arr.length);
    for (let i = 0; i < arr.length; i++) out[i] = arr[i] ^ _KEY[i % _KEY.length];
    return out;
}

function loadJson(path, def) {
    try {
        const [ok, raw] = GLib.file_get_contents(path);
        if (!ok) return def;
        // raw es Uint8Array; convertir a string ASCII para base64
        const rawStr = String.fromCharCode(...raw);
        // Intentar como datos cifrados (base64 → XOR → JSON)
        try {
            const decoded = GLib.base64_decode(rawStr); // devuelve Uint8Array
            const plain   = xorBytes(decoded);           // Uint8Array con bytes del JSON
            // plain es UTF-8 válido (era JSON antes de cifrar)
            return JSON.parse(new TextDecoder().decode(plain));
        } catch (_) {
            // Fallback: JSON plano sin cifrar (migración desde versión anterior)
            return JSON.parse(new TextDecoder().decode(raw));
        }
    } catch (_) {
        return def;
    }
}

function saveJson(path, data) {
    try {
        const json    = JSON.stringify(data, null, 2);
        const encoded = new TextEncoder().encode(json); // UTF-8 del JSON (válido)
        const ciphered = xorBytes(encoded);              // XOR → bytes binarios
        // base64_encode acepta Uint8Array y devuelve string ASCII puro
        const b64 = GLib.base64_encode(ciphered);
        // Guardar como bytes ASCII
        GLib.file_set_contents(path, new TextEncoder().encode(b64));
    } catch (e) {
        logError(e, '[prektbr] Error guardando ' + path);
    }
}

// ─── CSS global ────────────────────────────────────────────────────────────

const GLOBAL_CSS = `
.toolbar { background-color: #1e1e2e; border-bottom: 1px solid #313244; padding: 4px 8px; }
.url-entry { background-color: #313244; color: #cdd6f4; border: 1px solid #45475a;
    border-radius: 6px; padding: 4px 10px; font-size: 14px; min-height: 32px; }
.url-entry:focus { border-color: #89b4fa; background-color: #1e1e2e; }
.nav-button { background-color: transparent; color: #cdd6f4; border: none;
    border-radius: 6px; padding: 4px 8px; min-width: 32px; min-height: 32px; font-size: 16px; }
.nav-button:hover { background-color: #313244; }
.nav-button:disabled { color: #45475a; }
.tabbar { background-color: #181825; border-bottom: 1px solid #313244;
    padding: 4px 8px 0 8px; min-height: 36px; }
.tab-title-btn { background-color: transparent; color: inherit; border: none;
    border-radius: 4px 0 0 4px; padding: 4px 8px; font-size: 13px; min-width: 60px; }
.tab-title-btn:hover { background-color: rgba(255,255,255,0.05); }
.tab-btn { background-color: #1e1e2e; color: #6c7086; border: 1px solid #313244;
    border-bottom: none; border-radius: 6px 6px 0 0; padding: 4px 10px; font-size: 13px; min-width: 80px; }
.tab-btn:hover { background-color: #313244; color: #cdd6f4; }
.tab-active { background-color: #1e1e2e; color: #cdd6f4; border: 1px solid #45475a;
    border-bottom: 2px solid #89b4fa; font-weight: bold; }
.badge-normal { background-color: #313244; color: #a6e3a1; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; }
.badge-tor { background-color: #7f49a0; color: #f5c2e7; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-i2p { background-color: #1a6b3c; color: #a6e3a1; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-clear { background-color: #313244; color: #a6e3a1; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-file { background-color: #2a3550; color: #89b4fa; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-secure { background-color: #1a4731; color: #a6e3a1; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-insecure { background-color: #4a1a1a; color: #f38ba8; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-onion { background-color: #7f49a0; color: #f5c2e7; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.badge-eepsite { background-color: #1a6b3c; color: #a6e3a1; border-radius: 4px;
    padding: 2px 8px; font-size: 12px; font-family: monospace; font-weight: bold; }
.findbar { background-color: #1e1e2e; border-top: 1px solid #313244; padding: 4px 8px; }
.findbar-entry { background-color: #313244; color: #cdd6f4; border: 1px solid #45475a;
    border-radius: 6px; padding: 2px 8px; font-size: 13px; min-height: 28px; min-width: 200px; }
.findbar-entry:focus { border-color: #89b4fa; }
.findbar-label { color: #6c7086; font-size: 12px; padding: 0 8px; }
.inspector-tv { background-color: #0a0a1a; color: #89b4fa; font-family: monospace; font-size: 13px; padding: 10px; }
.terminal { background-color: #0d0d0d; color: #00ff41; font-family: monospace; font-size: 13px; padding: 10px; }
.statusbar { background-color: #181825; border-top: 1px solid #313244; color: #6c7086; font-size: 11px; padding: 2px 10px; }
.dl-progress trough { background-color: #313244; border-radius: 4px; min-height: 8px; }
.dl-progress progress { background-color: #89b4fa; border-radius: 4px; min-height: 8px; }
.new-tab-btn { background-color: transparent; color: #6c7086; border: none;
    border-radius: 4px; padding: 2px 8px; font-size: 18px; min-height: 28px; }
.new-tab-btn:hover { background-color: #313244; color: #cdd6f4; }
.sidebar { background-color: #181825; border-right: 1px solid #313244; min-width: 240px; }
.sidebar-title { background-color: #1e1e2e; color: #89b4fa; font-weight: bold; font-size: 13px;
    padding: 8px 12px; border-bottom: 1px solid #313244; }
.sidebar-item { background-color: transparent; color: #cdd6f4; border: none;
    border-radius: 4px; padding: 6px 10px; font-size: 12px; }
.sidebar-item:hover { background-color: #313244; }
.close-tab-btn { background-color: transparent; color: #6c7086; border: none;
    border-radius: 3px; padding: 0 3px; font-size: 12px; min-width: 16px; min-height: 16px; }
.close-tab-btn:hover { background-color: #f38ba8; color: #1e1e2e; }
`;

// ─── JS de protección anti-fingerprinting (igual al Python) ───────────────

const FP_PROTECTION_JS = `
(function() {
    'use strict';
    // 1. LETTERBOXING
    (function() {
        function rounded(v, step) { return Math.floor(v / step) * step || step; }
        const RW = rounded(window.innerWidth,  100);
        const RH = rounded(window.innerHeight, 100);
        const props = { innerWidth: RW, innerHeight: RH, outerWidth: RW, outerHeight: RH };
        for (const [k, v] of Object.entries(props)) {
            try { Object.defineProperty(window, k, { get: () => v, configurable: true }); } catch(e) {}
        }
    })();
    // 2. TIMING ATTACKS
    (function() {
        const GRANULARITY = 2;
        const origNow = performance.now.bind(performance);
        performance.now = function() { return Math.round(origNow() / GRANULARITY) * GRANULARITY; };
        const origDateNow = Date.now;
        Date.now = function() { return Math.round(origDateNow() / GRANULARITY) * GRANULARITY; };
        try { delete window.SharedArrayBuffer; } catch(e) {}
        try { delete window.Atomics; } catch(e) {}
    })();
    // 3. CANVAS FINGERPRINTING
    (function() {
        const NOISE_SEED = (Math.random() * 0xFFFFFFFF) | 0;
        function noiseByte(index) { return ((NOISE_SEED ^ (index * 1664525 + 1013904223)) >>> 24) & 1; }
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(type, ...args) {
            const ctx = this.getContext('2d');
            if (ctx && this.width > 0 && this.height > 0) {
                const id = ctx.getImageData(0, 0, this.width, this.height);
                for (let i = 0; i < id.data.length; i += 4) {
                    id.data[i] ^= noiseByte(i); id.data[i+1] ^= noiseByte(i+1); id.data[i+2] ^= noiseByte(i+2);
                }
                ctx.putImageData(id, 0, 0);
            }
            return origToDataURL.call(this, type, ...args);
        };
    })();
    // 4. AUDIOCONTEXT
    (function() {
        const ACtx = window.AudioContext || window.webkitAudioContext;
        if (!ACtx) return;
        const OrigAC = ACtx;
        const Patched = function(...args) {
            const ctx = new OrigAC(...args);
            const origCA = ctx.createAnalyser.bind(ctx);
            ctx.createAnalyser = function() {
                const a = origCA();
                const origGF = a.getFloatFrequencyData.bind(a);
                a.getFloatFrequencyData = function(arr) { origGF(arr); for (let i=0;i<arr.length;i++) arr[i]+=(Math.random()-0.5)*0.1; };
                return a;
            };
            return ctx;
        };
        try { if (window.AudioContext) window.AudioContext = Patched; } catch(e) {}
        try { if (window.webkitAudioContext) window.webkitAudioContext = Patched; } catch(e) {}
    })();
    // 5. NAVIGATOR
    (function() {
        const overrides = {
            platform: 'Win32', hardwareConcurrency: 4, deviceMemory: 8,
            languages: ['en-US','en'], language: 'en-US', plugins: [], mimeTypes: [],
            doNotTrack: '1', maxTouchPoints: 0, vendor: 'Google Inc.',
            vendorSub: '', productSub: '20030107', appName: 'Netscape', appVersion: '5.0 (Windows)',
        };
        for (const [k, v] of Object.entries(overrides)) {
            try { Object.defineProperty(navigator, k, { get: () => v, configurable: true }); } catch(e) {}
        }
    })();
    // 6. SCREEN
    (function() {
        const s = { width:1920, height:1080, availWidth:1920, availHeight:1080, colorDepth:24, pixelDepth:24 };
        for (const [k,v] of Object.entries(s)) {
            try { Object.defineProperty(screen, k, { get: () => v, configurable: true }); } catch(e) {}
        }
        try { Object.defineProperty(window, 'devicePixelRatio', { get: () => 1, configurable: true }); } catch(e) {}
    })();
    // 7. WEBGL
    (function() {
        function patchGL(ctx) {
            if (!ctx) return;
            const origGetParam = ctx.getParameter.bind(ctx);
            ctx.getParameter = function(p) {
                if (p === 37445) return 'Intel Inc.';
                if (p === 37446) return 'Intel Iris OpenGL Engine';
                return origGetParam(p);
            };
            const origGetExt = ctx.getExtension.bind(ctx);
            ctx.getExtension = function(name) {
                const blocked = ['WEBGL_debug_renderer_info','EXT_disjoint_timer_query','EXT_disjoint_timer_query_webgl2'];
                if (blocked.includes(name)) return null;
                return origGetExt(name);
            };
        }
        const origGetContext = HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext = function(type, ...args) {
            const ctx = origGetContext.call(this, type, ...args);
            if (ctx && (type==='webgl'||type==='webgl2'||type==='experimental-webgl')) patchGL(ctx);
            return ctx;
        };
    })();
    // 8. BATTERY
    if (navigator.getBattery) navigator.getBattery = () => Promise.resolve({ charging:true, chargingTime:0, dischargingTime:Infinity, level:1.0, addEventListener:()=>{}, removeEventListener:()=>{} });
    // 9. TIMEZONE
    Date.prototype.getTimezoneOffset = function() { return 0; };
    // 10. FUENTES
    if (document.fonts && document.fonts.check) {
        const generic = ['serif','sans-serif','monospace','cursive','fantasy','system-ui'];
        const origCheck = document.fonts.check.bind(document.fonts);
        document.fonts.check = (font, txt) => generic.some(g => font.toLowerCase().includes(g)) ? origCheck(font, txt) : false;
        const origLoad = document.fonts.load.bind(document.fonts);
        document.fonts.load = (font, txt) => generic.some(g => font.toLowerCase().includes(g)) ? origLoad(font, txt) : Promise.resolve([]);
    }
    // 11. WINDOW.NAME
    window.name = '';
    // 12. GEOLOCATION
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition = (ok, err) => { if (err) err({ code:1, message:'Permission denied' }); };
        navigator.geolocation.watchPosition = (ok, err) => { if (err) err({ code:1, message:'Permission denied' }); return 0; };
    }
    // 13. MEDIA DEVICES
    if (navigator.mediaDevices) {
        navigator.mediaDevices.enumerateDevices = () => Promise.resolve([]);
        navigator.mediaDevices.getUserMedia    = () => Promise.reject(new DOMException('NotAllowedError'));
        navigator.mediaDevices.getDisplayMedia = () => Promise.reject(new DOMException('NotAllowedError'));
    }
    // 14. SPEECH
    try { if (window.speechSynthesis) window.speechSynthesis.getVoices = () => []; delete window.SpeechRecognition; delete window.webkitSpeechRecognition; } catch(e) {}
})();
`;

// ─── TabData ───────────────────────────────────────────────────────────────

class TabData {
    constructor(webview, mode = 'normal') {
        this.webview = webview;
        this.mode = mode; // 'normal' | 'tor' | 'i2p'
    }
}

// ─── Aplicación ────────────────────────────────────────────────────────────

const PrekTBRApp = GObject.registerClass(
    { GTypeName: 'PrekTBRApp' },
    class PrekTBRApp extends Gtk.Application {
        _init() {
            super._init({
                application_id: 'com.cinnamolhyia.prektbr',
                flags: Gio.ApplicationFlags.HANDLES_OPEN,
            });
            this.homeUri = 'file://' + GLib.get_current_dir() + '/newtab.html';
            this.initialUrl = this.homeUri;
            this.darkMode = false;
            this.history  = loadJson(HISTORY_FILE,   []);
            this.bookmarks= loadJson(BOOKMARKS_FILE, []);
        }

        vfunc_startup() {
            super.vfunc_startup();
            const provider = new Gtk.CssProvider();
            provider.load_from_data(GLOBAL_CSS, -1);
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(), provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            );
        }

        vfunc_activate() {
            let win = this.active_window;
            if (!win) {
                win = new BrowserWindow(this);
                win.set_default_size(1280, 800);
            }
            win.present();
        }

        vfunc_open(files, hint) {
            let win = this.active_window;
            if (!win) {
                win = new BrowserWindow(this);
                win.set_default_size(1280, 800);
            }
            if (files && files.length > 0)
                win.openTab(files[0].get_uri());
            win.present();
        }

        addHistory(url, title = '') {
            if (!url || url.startsWith('file://') || url === 'about:blank') return;
            if (this.history.length > 0 && this.history[this.history.length - 1].url === url) return;
            this.history.push({ url, title: title || url, ts: new Date().toISOString() });
            if (this.history.length > 2000) this.history = this.history.slice(-2000);
            saveJson(HISTORY_FILE, this.history);
        }

        addBookmark(url, title = '') {
            if (!url || url === 'about:blank') return false;
            if (this.bookmarks.some(b => b.url === url)) return false;
            this.bookmarks.push({ url, title: title || url });
            saveJson(BOOKMARKS_FILE, this.bookmarks);
            return true;
        }

        removeBookmark(url) {
            this.bookmarks = this.bookmarks.filter(b => b.url !== url);
            saveJson(BOOKMARKS_FILE, this.bookmarks);
        }

        isBookmarked(url) {
            return this.bookmarks.some(b => b.url === url);
        }
    }
);

// ─── Ventana principal ─────────────────────────────────────────────────────

const BrowserWindow = GObject.registerClass(
    { GTypeName: 'BrowserWindow' },
    class BrowserWindow extends Gtk.ApplicationWindow {
        _init(app) {
            super._init({ application: app, title: 'PrekT-BR' });
            this._app = app;
            this._tabs = [];          // TabData[]
            this._currentTab = -1;
            this._sidebarMode = null; // null | 'bookmarks' | 'history'
            this._inspectorMode = false;
            this._findbarVisible = false;
            this._sidebarWidget = null;
            this._promptEndMark = null;

            this._buildUi();
            this.openTab(app.initialUrl);
        }

        // ── Construcción de UI ──────────────────────────────────────────────

        _buildUi() {
            const root = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 0 });

            // Barra de pestañas
            this._tabbarBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 2 });
            this._tabbarBox.add_css_class('tabbar');

            const newTabBtn = new Gtk.Button({ label: '+' });
            newTabBtn.add_css_class('new-tab-btn');
            newTabBtn.set_tooltip_text('Nueva pestaña');
            newTabBtn.connect('clicked', () => this.openTab());

            const tabbarScroll = new Gtk.ScrolledWindow({
                hscrollbar_policy: Gtk.PolicyType.AUTOMATIC,
                vscrollbar_policy: Gtk.PolicyType.NEVER,
                hexpand: true,
            });
            tabbarScroll.set_child(this._tabbarBox);
            tabbarScroll.set_min_content_height(38);

            const tabbarRow = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 0 });
            tabbarRow.add_css_class('tabbar');
            tabbarRow.append(tabbarScroll);
            tabbarRow.append(newTabBtn);

            // Barra de navegación
            this._backBtn    = this._navBtn('←',  'Atrás (Alt+Izq)',    () => this._onBack());
            this._forwardBtn = this._navBtn('→',  'Adelante (Alt+Der)', () => this._onForward());
            this._reloadBtn  = this._navBtn('↻',  'Recargar (Ctrl+R)',  () => this._onReload());
            this._homeBtn    = this._navBtn('⌂',  'Ir al inicio',       () => this._onHome());
            this._bookmarkStar = this._navBtn('★', 'Guardar marcador',   () => this._onToggleBookmark());

            this._urlEntry = new Gtk.Entry({ hexpand: true });
            this._urlEntry.add_css_class('url-entry');
            this._urlEntry.set_placeholder_text('Ingresa una URL o busca en DuckDuckGo...');
            this._urlEntry.connect('activate', () => this._onUrlActivate());

            this._badge = new Gtk.Label({ label: '' });
            this._badge.add_css_class('badge-normal');
            this._badge.set_tooltip_text('Modo de red actual');
            this._badge.set_visible(false);

            this._secBadge = new Gtk.Label({ label: '' });
            this._secBadge.set_tooltip_text('Estado de seguridad de la página');
            this._secBadge.set_visible(false);

            const bmarksBtn   = this._navBtn('⌘',  'Marcadores',              () => this._toggleSidebar('bookmarks'));
            const historyBtn  = this._navBtn('\u{1F552}\uFE0E', 'Historial',   () => this._toggleSidebar('history'));
            const terminalBtn = this._navBtn('>_', 'Terminal (Ctrl+Alt+T)',    () => this._onToggleTerminal());
            const findBtn     = this._navBtn('⌕',  'Buscar en página (Ctrl+F)',() => this._toggleFindbar());
            const inspBtn     = this._navBtn('</>', 'Inspector HTML',          () => this._toggleInspector());

            const navBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 4 });
            navBox.add_css_class('toolbar');
            for (const w of [this._backBtn, this._forwardBtn, this._reloadBtn, this._homeBtn,
                              this._secBadge, this._urlEntry, this._bookmarkStar, this._badge,
                              bmarksBtn, historyBtn, findBtn, inspBtn, terminalBtn])
                navBox.append(w);

            // Área de contenido
            this._contentArea = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 0 });
            this._contentArea.set_vexpand(true);
            this._contentArea.set_hexpand(true);

            // Stack de pestañas
            this._tabStack = new Gtk.Stack();
            this._tabStack.set_vexpand(true);
            this._tabStack.set_hexpand(true);
            this._contentArea.append(this._tabStack);

            // Terminal
            this._terminalVisible = false;
            this._terminalBuf = new Gtk.TextBuffer();
            this._terminalTv  = new Gtk.TextView({ buffer: this._terminalBuf, editable: true, cursor_visible: true });
            this._terminalTv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR);
            this._terminalTv.set_monospace(true);
            this._terminalTv.add_css_class('terminal');
            this._terminalTv.set_size_request(340, 200);

            const termScroll = new Gtk.ScrolledWindow({ vexpand: true, hexpand: false });
            termScroll.set_min_content_width(340);
            termScroll.set_min_content_height(200);
            termScroll.set_child(this._terminalTv);
            this._termScroll = termScroll;

            const termKey = new Gtk.EventControllerKey();
            termKey.connect('key-pressed', (ctrl, keyval, keycode, state) => this._onTerminalKey(ctrl, keyval, keycode, state));
            this._terminalTv.add_controller(termKey);

            // Inspector
            this._inspectorBuf = new Gtk.TextBuffer();
            this._inspectorTv  = new Gtk.TextView({ buffer: this._inspectorBuf, editable: true, cursor_visible: true });
            this._inspectorTv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR);
            this._inspectorTv.set_monospace(true);
            this._inspectorTv.add_css_class('inspector-tv');
            this._inspectorTv.set_size_request(400, 200);

            const inspScroll = new Gtk.ScrolledWindow({ vexpand: true, hexpand: false });
            inspScroll.set_min_content_width(400);
            inspScroll.set_min_content_height(200);
            inspScroll.set_child(this._inspectorTv);

            const inspBtnBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 4 });
            inspBtnBox.add_css_class('toolbar');
            inspBtnBox.append(this._navBtn('Cargar HTML', 'Obtener HTML actual', () => this._inspectorLoad()));
            inspBtnBox.append(this._navBtn('Aplicar',     'Aplicar HTML',        () => this._inspectorApply()));
            inspBtnBox.append(this._navBtn('Cerrar',      'Cerrar inspector',    () => this._closeInspector()));

            this._inspPanel = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 0 });
            this._inspPanel.append(inspBtnBox);
            this._inspPanel.append(inspScroll);

            const inspKey = new Gtk.EventControllerKey();
            inspKey.connect('key-pressed', (ctrl, keyval, keycode, state) => this._onInspectorKey(ctrl, keyval, keycode, state));
            this._inspectorTv.add_controller(inspKey);

            // Barra de búsqueda
            this._findbarBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 6 });
            this._findbarBox.add_css_class('findbar');
            this._findEntry = new Gtk.Entry();
            this._findEntry.add_css_class('findbar-entry');
            this._findEntry.set_placeholder_text('Buscar en página…');
            this._findEntry.connect('activate', () => this._findNext());
            this._findEntry.connect('changed',  () => this._findChanged());
            this._findLabel = new Gtk.Label({ label: '' });
            this._findLabel.add_css_class('findbar-label');
            for (const w of [
                this._findEntry,
                this._navBtn('↑', 'Anterior',       () => this._findPrev()),
                this._navBtn('↓', 'Siguiente',       () => this._findNext()),
                this._findLabel,
                this._navBtn('✕', 'Cerrar (Esc)',    () => this._closeFindbar()),
            ]) this._findbarBox.append(w);

            // Barra de estado
            this._statusbar = new Gtk.Label({ label: '' });
            this._statusbar.add_css_class('statusbar');
            this._statusbar.set_halign(Gtk.Align.START);
            this._statusbar.set_hexpand(true);
            this._statusbar.set_ellipsize(3);

            this._dlProgress = new Gtk.ProgressBar();
            this._dlProgress.add_css_class('dl-progress');
            this._dlProgress.set_visible(false);
            this._dlProgress.set_valign(Gtk.Align.CENTER);
            this._dlProgress.set_size_request(150, -1);

            const statusbarBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 8 });
            statusbarBox.add_css_class('statusbar');
            statusbarBox.append(this._statusbar);
            statusbarBox.append(this._dlProgress);

            root.append(tabbarRow);
            root.append(navBox);
            root.append(this._contentArea);
            root.append(this._findbarBox);
            root.append(statusbarBox);
            this.set_child(root);
            this._findbarBox.set_visible(false);

            // Atajos globales
            const keyGlobal = new Gtk.EventControllerKey();
            keyGlobal.connect('key-pressed', (ctrl, keyval, keycode, state) => this._onGlobalKey(ctrl, keyval, keycode, state));
            this.add_controller(keyGlobal);

            this._termPrint('PrekT-BR v2.1  —  escribe \'help\' para ver los comandos');
            this._termPrompt();
        }

        _navBtn(label, tooltip, callback) {
            const b = new Gtk.Button({ label });
            b.add_css_class('nav-button');
            b.set_tooltip_text(tooltip);
            b.connect('clicked', callback);
            return b;
        }

        // ── Pestañas ───────────────────────────────────────────────────────

        _makeTabWidget(idx) {
            const box = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 0 });
            box.add_css_class('tab-btn');

            const titleBtn = new Gtk.Button({ label: `Tab ${idx + 1}` });
            titleBtn.add_css_class('tab-title-btn');
            titleBtn.set_hexpand(true);
            titleBtn.connect('clicked', () => this._onTabClick(idx));

            const closeBtn = new Gtk.Button({ label: 'x' });
            closeBtn.add_css_class('close-tab-btn');
            closeBtn.connect('clicked', () => this._onCloseTab(idx));

            box.append(titleBtn);
            box.append(closeBtn);
            box._titleBtn = titleBtn;
            return box;
        }

        openTab(uri = null, mode = 'normal') {
            const wv = this._makeWebview(mode);
            const td = new TabData(wv, mode);
            this._tabs.push(td);
            const idx = this._tabs.length - 1;

            this._tabStack.add_named(wv, `tab${idx}`);
            const tabWidget = this._makeTabWidget(idx);
            this._tabbarBox.append(tabWidget);

            this._setupDownloadHandler(wv);
            this._switchTab(idx);
            wv.load_uri(uri || this._app.homeUri);
        }

        _onCloseTab(idx) {
            if (this._tabs.length === 1) {
                this._tabs[0].webview.load_uri(this._app.homeUri);
                return;
            }
            const td = this._tabs[idx];
            this._clearTabData(td);
            this._tabStack.remove(td.webview);
            this._tabs.splice(idx, 1);
            this._rebuildTabbar();
            this._switchTab(Math.min(idx, this._tabs.length - 1));
        }

        _clearTabData(td) {
            try {
                const ns = td.webview.get_network_session();
                if (ns) {
                    const wds = ns.get_website_data_store();
                    if (wds) {
                        wds.clear(
                            WebKit.WebsiteDataTypes.COOKIES |
                            WebKit.WebsiteDataTypes.DISK_CACHE |
                            WebKit.WebsiteDataTypes.MEMORY_CACHE |
                            WebKit.WebsiteDataTypes.SESSION_STORAGE |
                            WebKit.WebsiteDataTypes.LOCAL_STORAGE |
                            WebKit.WebsiteDataTypes.INDEXED_DB_DATABASES |
                            WebKit.WebsiteDataTypes.OFFLINE_APPLICATION_CACHE,
                            0, null, null
                        );
                    }
                }
            } catch (e) {
                logError(e, '[prektbr] Error limpiando datos de pestaña');
            }
        }

        _rebuildTabbar() {
            let child = this._tabbarBox.get_first_child();
            while (child) {
                const next = child.get_next_sibling();
                this._tabbarBox.remove(child);
                child = next;
            }
            for (let i = 0; i < this._tabs.length; i++) {
                const td = this._tabs[i];
                const tw = this._makeTabWidget(i);
                const title = td.webview.get_title();
                if (title) {
                    const short = title.length > 14 ? title.slice(0, 14) + '...' : title;
                    tw._titleBtn.set_label(short);
                }
                this._tabbarBox.append(tw);
            }
        }

        _onTabClick(idx) { this._switchTab(idx); }

        _switchTab(idx) {
            if (idx < 0 || idx >= this._tabs.length) return;
            let child = this._tabbarBox.get_first_child();
            let i = 0;
            while (child) {
                child.remove_css_class('tab-active');
                if (i === idx) child.add_css_class('tab-active');
                child = child.get_next_sibling();
                i++;
            }
            this._currentTab = idx;
            this._tabStack.set_visible_child_name(`tab${idx}`);
            const td = this._tabs[idx];
            const uri = td.webview.get_uri();
            this._urlEntry.set_text(uri && uri !== 'about:blank' ? uri : '');
            this._updateBadge(td.mode);
            this._updateNavButtons();
            this._updateBookmarkStar();
            this._updateSecurityBadge(td.webview.get_uri() || '');
        }

        _wv() { return this._tabs[this._currentTab].webview; }
        _td() { return this._tabs[this._currentTab]; }

        // ── Creación de WebView ─────────────────────────────────────────────

        _makeWebview(mode = 'normal') {
            let wv;
            if (mode === 'tor') {
                const ns = WebKit.NetworkSession.new_ephemeral();
                const ps = WebKit.NetworkProxySettings.new('socks5://127.0.0.1:9050', null);
                ns.set_proxy_settings(WebKit.NetworkProxyMode.CUSTOM, ps);
                wv = new WebKit.WebView({ network_session: ns });
            } else if (mode === 'i2p') {
                const ns = WebKit.NetworkSession.new_ephemeral();
                const ps = WebKit.NetworkProxySettings.new('http://127.0.0.1:4444', null);
                ns.set_proxy_settings(WebKit.NetworkProxyMode.CUSTOM, ps);
                wv = new WebKit.WebView({ network_session: ns });
            } else {
                wv = new WebKit.WebView();
            }

            const s = WebKit.Settings.new();
            s.set_enable_developer_extras(false);
            s.set_javascript_can_access_clipboard(false);
            s.set_enable_webrtc(false);
            s.set_enable_mediasource(false);
            s.set_enable_encrypted_media(false);
            s.set_enable_back_forward_navigation_gestures(false);
            s.set_media_playback_requires_user_gesture(true);
            s.set_javascript_can_open_windows_automatically(false);
            s.set_allow_modal_dialogs(false);
            s.set_enable_page_cache(false);
            s.set_user_agent('Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0');
            wv.set_settings(s);
            wv.set_vexpand(true);
            wv.set_hexpand(true);

            wv.connect('notify::uri',                     () => this._onUriChanged(wv));
            wv.connect('notify::title',                   () => this._onTitleChanged(wv));
            wv.connect('load-changed',  (w, ev)          => this._onLoadChanged(w, ev));
            wv.connect('notify::estimated-load-progress', () => this._onProgress(wv));

            // Anti-fingerprinting via UserContentManager
            const ucm = wv.get_user_content_manager();
            try {
                const script = new WebKit.UserScript(
                    FP_PROTECTION_JS,
                    WebKit.UserContentInjectedFrames.TOP_FRAME,
                    WebKit.UserScriptInjectionTime.START,
                    null, null
                );
                ucm.add_script(script);
            } catch (e) {
                logError(e, '[prektbr] UserContentManager fallback');
                wv.connect('load-changed', (w, ev) => {
                    if (ev === WebKit.LoadEvent.STARTED)
                        w.evaluate_javascript(FP_PROTECTION_JS, -1, null, null, null, null);
                });
            }

            return wv;
        }

        // ── Señales del WebView ─────────────────────────────────────────────

        _onUriChanged(wv) {
            if (!this._tabs.length) return;
            const uri = wv.get_uri();
            if (!uri || uri === 'about:blank') return;
            if (wv === this._wv()) {
                this._urlEntry.set_text(uri);
                this._updateBookmarkStar();
                this._updateNavButtons();
                this._updateSecurityBadge(uri);
            }
            this._app.addHistory(uri, wv.get_title() || uri);
        }

        _onTitleChanged(wv) {
            if (!this._tabs.length) return;
            const title = wv.get_title() || '';
            let child = this._tabbarBox.get_first_child();
            let i = 0;
            while (child) {
                if (i < this._tabs.length && this._tabs[i].webview === wv && child._titleBtn) {
                    const short = title.length > 14 ? title.slice(0, 14) + '...' : (title || `Tab ${i + 1}`);
                    child._titleBtn.set_label(short);
                    break;
                }
                child = child.get_next_sibling();
                i++;
            }
            if (wv === this._wv())
                this.set_title(title ? `PrekT-BR — ${title}` : 'PrekT-BR');
        }

        _onLoadChanged(wv, event) {
            if (event === WebKit.LoadEvent.STARTED) {
                this._reloadBtn.set_label('✕');
                this._reloadBtn.set_tooltip_text('Detener carga');
            } else if (event === WebKit.LoadEvent.FINISHED) {
                this._reloadBtn.set_label('↻');
                this._reloadBtn.set_tooltip_text('Recargar (Ctrl+R)');
                this._statusbar.set_label('');
                if (this._app.darkMode && wv === this._wv())
                    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => { this._applyDarkCss(); return false; });
            }
        }

        _onProgress(wv) {
            if (wv !== this._wv()) return;
            const p = wv.get_estimated_load_progress();
            if (p > 0 && p < 1)
                this._statusbar.set_label(`Cargando… ${Math.round(p * 100)}%`);
            else
                this._statusbar.set_label('');
        }

        // ── Navegación ──────────────────────────────────────────────────────

        _onBack()    { if (this._wv().can_go_back())    this._wv().go_back(); }
        _onForward() { if (this._wv().can_go_forward()) this._wv().go_forward(); }
        _onHome()    { this._wv().load_uri(this._app.homeUri); }

        _onUrlActivate() {
            const text = this._urlEntry.get_text().trim();
            if (!text) return;
            this._wv().load_uri(this._resolveInput(text));
        }

        _resolveInput(text) {
            const lower = text.trim().toLowerCase();
            for (const scheme of ['javascript:', 'data:', 'vbscript:', 'blob:']) {
                if (lower.startsWith(scheme)) {
                    this._statusbar.set_label(`Esquema bloqueado: ${scheme}`);
                    return 'about:blank';
                }
            }
            if (text.startsWith('http://') || text.startsWith('https://') ||
                text.startsWith('about:') || text.startsWith('file://'))
                return text;
            if ((text.includes('.') && !text.includes(' ')) || text.split(':')[0] === 'localhost')
                return 'https://' + text;
            return 'https://duckduckgo.com/?q=' + encodeURIComponent(text);
        }

        _updateNavButtons() {
            if (!this._tabs.length) return;
            this._backBtn.set_sensitive(this._wv().can_go_back());
            this._forwardBtn.set_sensitive(this._wv().can_go_forward());
        }

        // ── Marcadores ──────────────────────────────────────────────────────

        _onToggleBookmark() {
            const wv = this._wv();
            const uri = wv.get_uri();
            if (!uri || uri === 'about:blank') return;
            if (this._app.isBookmarked(uri)) {
                this._app.removeBookmark(uri);
                this._bookmarkStar.set_label('☆');
                this._statusbar.set_label('Marcador eliminado');
            } else {
                this._app.addBookmark(uri, wv.get_title() || uri);
                this._bookmarkStar.set_label('★');
                this._statusbar.set_label('Marcador guardado');
            }
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => { this._statusbar.set_label(''); return false; });
            if (this._sidebarMode === 'bookmarks') this._showSidebar('bookmarks');
        }

        _updateBookmarkStar() {
            if (!this._tabs.length) return;
            const uri = this._wv().get_uri();
            this._bookmarkStar.set_label(uri && this._app.isBookmarked(uri) ? '★' : '☆');
        }

        // ── Sidebar ─────────────────────────────────────────────────────────

        _toggleSidebar(mode) {
            if (this._sidebarMode === mode) this._closeSidebar();
            else this._showSidebar(mode);
        }

        _closeSidebar() {
            if (this._sidebarWidget) {
                this._contentArea.remove(this._sidebarWidget);
                this._sidebarWidget = null;
            }
            this._sidebarMode = null;
        }

        _showSidebar(mode) {
            this._closeSidebar();
            this._sidebarMode = mode;

            const outer = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 0 });
            outer.add_css_class('sidebar');

            const titleBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 0 });
            titleBox.add_css_class('sidebar-title');
            const lbl = new Gtk.Label({ label: mode === 'bookmarks' ? 'Marcadores' : 'Historial', hexpand: true, halign: Gtk.Align.START });
            const closeBtn = new Gtk.Button({ label: 'Cerrar' });
            closeBtn.add_css_class('nav-button');
            closeBtn.connect('clicked', () => this._closeSidebar());
            titleBox.append(lbl);
            titleBox.append(closeBtn);

            const scroll = new Gtk.ScrolledWindow({ vexpand: true });
            scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);

            const listBox = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 1 });
            listBox.set_margin_top(4); listBox.set_margin_bottom(4);
            listBox.set_margin_start(4); listBox.set_margin_end(4);

            if (mode === 'bookmarks') {
                const items = [...this._app.bookmarks];
                if (!items.length) {
                    const e = new Gtk.Label({ label: 'Sin marcadores aún', margin_top: 20 });
                    e.add_css_class('sidebar-item');
                    listBox.append(e);
                }
                for (const b of items) this._sidebarItem(listBox, b.title, b.url, true);
            } else {
                const items = [...this._app.history.slice(-200)].reverse();
                if (!items.length) {
                    const e = new Gtk.Label({ label: 'El historial está vacío', margin_top: 20 });
                    e.add_css_class('sidebar-item');
                    listBox.append(e);
                }
                for (const h of items) {
                    const ts = (h.ts || '').slice(0, 10);
                    this._sidebarItem(listBox, `[${ts}] ${h.title || h.url}`, h.url, false);
                }
            }

            scroll.set_child(listBox);
            outer.append(titleBox);
            outer.append(scroll);
            this._contentArea.prepend(outer);
            this._sidebarWidget = outer;
        }

        _sidebarItem(box, label, url, removable = false) {
            const row = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 2 });
            const btn = new Gtk.Button({ label, hexpand: true, halign: Gtk.Align.FILL });
            btn.add_css_class('sidebar-item');
            btn.connect('clicked', () => this._wv().load_uri(url));
            row.append(btn);
            if (removable) {
                const del = new Gtk.Button({ label: 'Quitar' });
                del.add_css_class('close-tab-btn');
                del.connect('clicked', () => {
                    this._app.removeBookmark(url);
                    this._showSidebar('bookmarks');
                });
                row.append(del);
            }
            box.append(row);
        }

        // ── Badge de red ────────────────────────────────────────────────────

        _updateBadge(mode) {
            this._badge.remove_css_class('badge-normal');
            this._badge.remove_css_class('badge-tor');
            this._badge.remove_css_class('badge-i2p');
            this._badge.remove_css_class('badge-clear');
            if (mode === 'tor') {
                this._badge.set_label('TOR');
                this._badge.add_css_class('badge-tor');
            } else if (mode === 'i2p') {
                this._badge.set_label('I2P');
                this._badge.add_css_class('badge-i2p');
            } else {
                this._badge.set_label('Clear');
                this._badge.add_css_class('badge-clear');
            }
            this._badge.set_visible(true);
        }

        // ── Modo oscuro ──────────────────────────────────────────────────────

        _applyDarkCss() {
            const css = ':root{color-scheme:dark!important}*{background-color:#111!important;color:#eee!important;border-color:#333!important}a{color:#8ab4f8!important}img{filter:brightness(0.85)}';
            const js = `(function(){let el=document.getElementById('prektbr-dark');if(!el){el=document.createElement('style');el.id='prektbr-dark';document.head.appendChild(el);}el.textContent=\`${css}\`;})();`;
            this._wv().evaluate_javascript(js, -1, null, null, null, null);
        }

        // ── Atajos de teclado ────────────────────────────────────────────────

        _onGlobalKey(ctrl, keyval, keycode, state) {
            const ctrlHeld  = !!(state & Gdk.ModifierType.CONTROL_MASK);
            const altHeld   = !!(state & Gdk.ModifierType.ALT_MASK);
            const shiftHeld = !!(state & Gdk.ModifierType.SHIFT_MASK);

            if (ctrlHeld && !altHeld) {
                if (keyval === Gdk.KEY_t) { this.openTab(); return true; }
                if (keyval === Gdk.KEY_w) { this._onCloseTab(this._currentTab); return true; }
                if (keyval === Gdk.KEY_l) { this._urlEntry.grab_focus(); this._urlEntry.select_region(0, -1); return true; }
                if (keyval === Gdk.KEY_r && !shiftHeld) { this._wv().reload(); return true; }
                if (keyval === Gdk.KEY_r &&  shiftHeld) { this._wv().reload_bypass_cache(); return true; }
                if (keyval === Gdk.KEY_f) { this._toggleFindbar(); return true; }
                if (keyval === Gdk.KEY_plus || keyval === Gdk.KEY_equal) {
                    const wv = this._wv(); wv.set_zoom_level(Math.min(wv.get_zoom_level() + 0.1, 5.0)); return true;
                }
                if (keyval === Gdk.KEY_minus) {
                    const wv = this._wv(); wv.set_zoom_level(Math.max(wv.get_zoom_level() - 0.1, 0.1)); return true;
                }
                if (keyval === Gdk.KEY_0) { this._wv().set_zoom_level(1.0); return true; }
            }
            if (ctrlHeld && altHeld) {
                if (keyval === Gdk.KEY_t || keyval === Gdk.KEY_Return) { this._onToggleTerminal(); return true; }
            }
            if (!ctrlHeld && !altHeld) {
                if (keyval === Gdk.KEY_Escape) {
                    if (this._findbarVisible) { this._closeFindbar(); return true; }
                    if (this._inspectorMode) { this._closeInspector(); return true; }
                }
            }
            if (altHeld && !ctrlHeld) {
                if (keyval === Gdk.KEY_Left)  { if (this._wv().can_go_back())    this._wv().go_back();    return true; }
                if (keyval === Gdk.KEY_Right) { if (this._wv().can_go_forward()) this._wv().go_forward(); return true; }
            }
            return false;
        }

        // ── Badge de seguridad ───────────────────────────────────────────────

        _updateSecurityBadge(uri) {
            if (!uri || uri.startsWith('about:')) { this._secBadge.set_visible(false); return; }

            // Parsear esquema y host manualmente para evitar que new URL() falle
            // con URIs como about:blank o esquemas no estándar
            let scheme = '', host = '';
            try {
                const u = new URL(uri);
                scheme = u.protocol.replace(':', ''); // "https", "http", "file", etc.
                host   = u.hostname;
            } catch (_) {
                // URI malformada — ocultar badge
                this._secBadge.set_visible(false);
                return;
            }

            for (const cls of ['badge-secure','badge-insecure','badge-onion','badge-eepsite','badge-file'])
                this._secBadge.remove_css_class(cls);

            if (scheme === 'file') {
                this._secBadge.set_label('F'); this._secBadge.add_css_class('badge-file');
                this._secBadge.set_tooltip_text('Archivo local');
            } else if (host.endsWith('.onion')) {
                this._secBadge.set_label('O'); this._secBadge.add_css_class('badge-onion');
                this._secBadge.set_tooltip_text('Onion — servicio oculto Tor');
            } else if (host.endsWith('.i2p') || host.endsWith('.loki')) {
                this._secBadge.set_label('E'); this._secBadge.add_css_class('badge-eepsite');
                this._secBadge.set_tooltip_text('Eepsite — servicio I2P/Lokinet');
            } else if (scheme === 'https') {
                this._secBadge.set_label('S'); this._secBadge.add_css_class('badge-secure');
                this._secBadge.set_tooltip_text('Seguro — conexión HTTPS');
            } else {
                this._secBadge.set_label('I'); this._secBadge.add_css_class('badge-insecure');
                this._secBadge.set_tooltip_text('Inseguro — conexión HTTP sin cifrar');
            }
            this._secBadge.set_visible(true);
        }

        // ── Buscar en página ─────────────────────────────────────────────────

        _toggleFindbar() {
            if (this._findbarVisible) this._closeFindbar();
            else { this._findbarBox.set_visible(true); this._findbarVisible = true; this._findEntry.grab_focus(); }
        }

        _closeFindbar() {
            this._findbarBox.set_visible(false);
            this._findbarVisible = false;
            this._wv().get_find_controller().search_finish();
            this._findLabel.set_label('');
        }

        _findChanged() {
            const text = this._findEntry.get_text();
            const fc = this._wv().get_find_controller();
            if (text) fc.search(text, WebKit.FindOptions.CASE_INSENSITIVE | WebKit.FindOptions.WRAP_AROUND, 1000);
            else { fc.search_finish(); this._findLabel.set_label(''); }
        }

        _findNext() { if (this._findEntry.get_text()) this._wv().get_find_controller().search_next(); }
        _findPrev() { if (this._findEntry.get_text()) this._wv().get_find_controller().search_previous(); }

        // ── Inspector HTML ───────────────────────────────────────────────────

        _toggleInspector() {
            if (this._inspectorMode) this._closeInspector();
            else this._openInspector();
        }

        _openInspector() {
            if (this._inspectorMode) return;
            if (this._terminalVisible) {
                this._statusbar.set_label('Cierra la terminal primero (Ctrl+Alt+T)');
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => { this._statusbar.set_label(''); return false; });
                return;
            }
            this._inspectorMode = true;
            this._contentArea.append(this._inspPanel);
            this._inspectorLoad();
        }

        _closeInspector() {
            if (!this._inspectorMode) return;
            this._contentArea.remove(this._inspPanel);
            this._inspectorMode = false;
        }

        _inspectorLoad() {
            this._inspectorBuf.set_text('Cargando HTML…', -1);
            const wv = this._wv();
            wv.evaluate_javascript('document.documentElement.outerHTML', -1, null, null, null,
                (source, result) => {
                    try {
                        const val = source.evaluate_javascript_finish(result);
                        const html = val ? val.to_string() : '';
                        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                            this._inspectorBuf.set_text(html || '[HTML vacío]', -1);
                            return false;
                        });
                    } catch (e) {
                        logError(e, '[prektbr] inspector');
                        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                            this._inspectorBuf.set_text('[Error al obtener HTML]', -1);
                            return false;
                        });
                    }
                }
            );
        }

        _inspectorApply() {
            const start = this._inspectorBuf.get_start_iter();
            const end   = this._inspectorBuf.get_end_iter();
            const html  = this._inspectorBuf.get_text(start, end, false);
            const escaped = html.replace(/\\/g, '\\\\').replace(/`/g, '\\`');
            const js = `document.open();document.write(\`${escaped}\`);document.close();`;
            this._wv().evaluate_javascript(js, -1, null, null, null, null);
        }

        _onInspectorKey(ctrl, keyval, keycode, state) {
            const ctrlHeld = !!(state & Gdk.ModifierType.CONTROL_MASK);
            if (ctrlHeld && keyval === Gdk.KEY_Return) { this._inspectorApply(); return true; }
            if (keyval === Gdk.KEY_Escape) { this._closeInspector(); return true; }
            return false;
        }

        // ── Descargas ────────────────────────────────────────────────────────

        _setupDownloadHandler(wv) {
            const ns = wv.get_network_session();
            if (ns) ns.connect('download-started', (session, dl) => this._onDownloadStarted(session, dl));
        }

        _onDownloadStarted(session, download) {
            download.connect('decide-destination', (dl, fname) => this._onDecideDestination(dl, fname));
            download.connect('failed', (dl, err) => this._onDownloadFailed(dl, err));
        }

        _onDecideDestination(download, suggestedFilename) {
            if (!suggestedFilename) suggestedFilename = 'descarga';
            const dialog = new Gtk.FileDialog();
            dialog.set_title('Guardar archivo');
            dialog.set_initial_name(suggestedFilename);
            dialog.save(this, null, (d, result) => {
                try {
                    const gfile = d.save_finish(result);
                    const dest  = gfile.get_path();
                    const fname = GLib.path_get_basename(dest);
                    download.set_destination(dest);
                    this._statusbar.set_label(`Descargando: ${fname}  0%`);
                    this._dlProgress.set_fraction(0);
                    this._dlProgress.set_visible(true);
                    download.connect('notify::estimated-progress', (dl) => {
                        const p = dl.get_estimated_progress();
                        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                            this._dlProgress.set_fraction(p);
                            this._statusbar.set_label(`Descargando: ${fname}  ${Math.round(p * 100)}%`);
                            return false;
                        });
                    });
                    download.connect('finished', () => {
                        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                            this._dlProgress.set_fraction(1.0);
                            this._statusbar.set_label(`Descarga completa: ${fname}`);
                            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 3500, () => {
                                this._dlProgress.set_visible(false);
                                this._dlProgress.set_fraction(0);
                                this._statusbar.set_label('');
                                return false;
                            });
                            return false;
                        });
                    });
                } catch (_) {
                    download.cancel();
                }
            }, download);
            return true;
        }

        _onDownloadFailed(download, error) {
            GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                this._dlProgress.set_visible(false);
                this._dlProgress.set_fraction(0);
                this._statusbar.set_label(`Error de descarga: ${error}`);
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 4000, () => { this._statusbar.set_label(''); return false; });
                return false;
            });
        }

        // ── Toggle terminal ───────────────────────────────────────────────────

        _onReload() {
            const wv = this._wv();
            if (wv.is_loading()) wv.stop_loading();
            else wv.reload();
        }

        _onToggleTerminal() {
            if (this._inspectorMode) {
                this._statusbar.set_label('Cierra el inspector primero (Esc)');
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => { this._statusbar.set_label(''); return false; });
                return;
            }
            if (this._terminalVisible) {
                this._contentArea.remove(this._termScroll);
                this._terminalVisible = false;
            } else {
                this._contentArea.append(this._termScroll);
                this._terminalVisible = true;
                this._terminalTv.grab_focus();
            }
        }

        // ── Modos de red ──────────────────────────────────────────────────────

        _enableNetworkMode(mode) {
            const td = this._td();
            if (td.mode === mode) {
                this._termPrint(`La pestaña ya está en modo ${mode.toUpperCase()}.`);
                this._termPrompt();
                return;
            }
            const oldUri = td.webview.get_uri() || this._app.homeUri;
            const newWv  = this._makeWebview(mode);
            const idx    = this._currentTab;

            this._tabStack.remove(td.webview);
            td.webview = newWv;
            td.mode    = mode;
            this._tabStack.add_named(newWv, `tab${idx}`);
            this._tabStack.set_visible_child_name(`tab${idx}`);
            this._setupDownloadHandler(newWv);
            newWv.load_uri(oldUri !== 'about:blank' ? oldUri : this._app.homeUri);
            this._updateBadge(mode);

            if (mode === 'tor') {
                this._termPrint('  MODO TOR ACTIVADO — WebRTC deshabilitado');
                this._termPrint('  Usa http:// (sin s) para sitios .onion');
            } else if (mode === 'i2p') {
                this._termPrint('  MODO I2P ACTIVADO — Proxy HTTP 127.0.0.1:4444');
                this._termPrint('  Navega a sitios .i2p normalmente');
            }
            this._termPrompt();
        }

        _disableNetworkMode() {
            const td = this._td();
            if (td.mode === 'normal') {
                this._termPrint('La pestaña ya está en modo normal.');
                this._termPrompt();
                return;
            }
            const oldUri = td.webview.get_uri() || this._app.homeUri;
            const newWv  = this._makeWebview('normal');
            const idx    = this._currentTab;

            this._tabStack.remove(td.webview);
            td.webview = newWv;
            td.mode    = 'normal';
            this._tabStack.add_named(newWv, `tab${idx}`);
            this._tabStack.set_visible_child_name(`tab${idx}`);
            this._setupDownloadHandler(newWv);
            newWv.load_uri(oldUri !== 'about:blank' ? oldUri : this._app.homeUri);
            this._updateBadge('normal');
            this._termPrint('  Modo normal restaurado.');
            this._termPrompt();
        }

        // ── Terminal ──────────────────────────────────────────────────────────

        _termPrint(text, noNl = false) {
            const end = this._terminalBuf.get_end_iter();
            this._terminalBuf.insert(end, noNl ? text : text + '\n', -1);
            const end2 = this._terminalBuf.get_end_iter();
            this._terminalTv.scroll_to_iter(end2, 0.0, true, 0.0, 1.0);
        }

        _termPrompt() {
            const end = this._terminalBuf.get_end_iter();
            this._terminalBuf.insert(end, '> ', -1);
            const end2 = this._terminalBuf.get_end_iter();
            this._promptEndMark = this._terminalBuf.create_mark('prompt_end', end2, true);
        }

        _onTerminalKey(ctrl, keyval, keycode, state) {
            if (keyval === Gdk.KEY_Return || keyval === Gdk.KEY_KP_Enter) {
                const start = this._terminalBuf.get_start_iter();
                const end   = this._terminalBuf.get_end_iter();
                const full  = this._terminalBuf.get_text(start, end, false).trimEnd();
                const lines = full.split('\n');
                if (lines.length) {
                    const last = lines[lines.length - 1].trim();
                    if (last.startsWith('> ')) {
                        const cmd = last.slice(2).trim();
                        if (cmd) { this._termPrint(''); this._runCommand(cmd); return true; }
                    }
                }
                this._termPrint('');
                this._termPrompt();
                return true;
            }
            // Proteger prompt
            if ([Gdk.KEY_BackSpace, Gdk.KEY_Delete, Gdk.KEY_Left, Gdk.KEY_Home,
                 Gdk.KEY_KP_Left, Gdk.KEY_KP_Home].includes(keyval)) {
                if (this._promptEndMark) {
                    const insert = this._terminalBuf.get_insert();
                    const cursor = this._terminalBuf.get_iter_at_mark(insert);
                    const limit  = this._terminalBuf.get_iter_at_mark(this._promptEndMark);
                    if (cursor.compare(limit) <= 0) return true;
                }
            }
            return false;
        }

        // ── Comandos de terminal ───────────────────────────────────────────────

        _runCommand(raw) {
            const spaceIdx = raw.indexOf(' ');
            const cmd  = (spaceIdx >= 0 ? raw.slice(0, spaceIdx) : raw).toLowerCase();
            const args = spaceIdx >= 0 ? raw.slice(spaceIdx + 1).trim() : '';
            const nav  = (url) => this._wv().load_uri(url);

            switch (cmd) {
            case 'help':
                this._termPrint(
                    '─── Navegación ───────────────────────────────\n' +
                    '  open <url>            → abre URL en pestaña actual\n' +
                    '  newtab [url]          → abre nueva pestaña\n' +
                    '  closetab              → cierra pestaña actual\n' +
                    '  tab <n>               → cambia a pestaña n (1-based)\n' +
                    '  back / forward        → historial del navegador\n' +
                    '  reload / reloadhard   → recarga\n' +
                    '  home                  → página de inicio\n' +
                    '  zoom <n>              → nivel de zoom (0.1–5.0)\n' +
                    '─── Búsqueda ─────────────────────────────────\n' +
                    '  ddg / google / yt / wiki <consulta>\n' +
                    '─── Redes alternativas ───────────────────────\n' +
                    '  tormode / i2pmode / clearnet\n' +
                    '  loki <dir>   whoami   serverip\n' +
                    '─── Marcadores e historial ───────────────────\n' +
                    '  bookmark   bookmarks   history [n]\n' +
                    '─── Utilidades ───────────────────────────────\n' +
                    '  dark  calc <expr>  time  date  echo  clear\n' +
                    '  clearcookies  clearall  about  quit\n'
                );
                break;

            case 'open': case 'new':
                if (args) nav(this._resolveInput(args));
                else this._termPrint('Uso: open <url>');
                break;

            case 'newtab':
                this.openTab(args ? this._resolveInput(args) : null);
                break;

            case 'closetab':
                this._onCloseTab(this._currentTab);
                break;

            case 'tab': {
                const n = parseInt(args, 10) - 1;
                if (!isNaN(n)) this._switchTab(n);
                else this._termPrint('Uso: tab <número>');
                break;
            }

            case 'back':    if (this._wv().can_go_back())    this._wv().go_back();    break;
            case 'forward': if (this._wv().can_go_forward()) this._wv().go_forward(); break;
            case 'reload':    this._wv().reload(); break;
            case 'reloadhard': this._wv().reload_bypass_cache(); break;
            case 'home':   nav(this._app.homeUri); break;

            case 'zoom': {
                if (args) {
                    const level = parseFloat(args);
                    if (!isNaN(level) && level >= 0.1 && level <= 5.0) {
                        this._wv().set_zoom_level(level);
                        this._termPrint(`Zoom: ${level.toFixed(1)}x`);
                    } else this._termPrint('Zoom válido: 0.1 – 5.0 (1.0 = normal)');
                } else {
                    this._termPrint(`Zoom actual: ${this._wv().get_zoom_level().toFixed(1)}x  — uso: zoom <número>`);
                }
                break;
            }

            case 'ddg':
                nav(args ? `https://duckduckgo.com/?q=${encodeURIComponent(args)}` : 'https://duckduckgo.com'); break;
            case 'google':
                nav(args ? `https://www.google.com/search?q=${encodeURIComponent(args)}` : 'https://www.google.com'); break;
            case 'yt':
                nav(args ? `https://www.youtube.com/results?search_query=${encodeURIComponent(args)}` : 'https://www.youtube.com'); break;
            case 'wiki':
                nav(args ? `https://es.wikipedia.org/wiki/${encodeURIComponent(args)}` : 'https://es.wikipedia.org'); break;

            case 'loki': {
                if (args) {
                    let addr = args.trim().replace(/^https?:\/\//, '');
                    if (!addr.endsWith('.loki')) addr += '.loki';
                    nav(`http://${addr}`);
                } else this._termPrint('Uso: loki <direccion>');
                break;
            }

            case 'tormode':   this._enableNetworkMode('tor'); return;
            case 'i2pmode':   this._enableNetworkMode('i2p'); return;
            case 'clearnet':  this._disableNetworkMode(); return;

            case 'whoami':
                this._termPrint('Consultando IP pública...');
                // GJS no tiene fetch nativo fácilmente disponible sin Soup, usamos un mensaje simple
                try {
                    const session = new Gio.NetworkAddress.resolve_async;
                    // Alternativa: usar GLib.spawn_async con curl
                    const [ok, out, err, status] = GLib.spawn_command_line_sync(
                        'curl -s --max-time 7 https://api.ipify.org'
                    );
                    if (ok) {
                        const ip = new TextDecoder().decode(out).trim();
                        this._termPrint(`IP pública: ${ip}`);
                    } else {
                        this._termPrint('Error consultando IP.');
                    }
                } catch (e) {
                    this._termPrint(`Error: ${e.message}`);
                }
                break;

            case 'serverip': {
                const td = this._td();
                if (td.mode !== 'normal') {
                    this._termPrint(`serverip no disponible en modo ${td.mode.toUpperCase()}.`);
                } else {
                    const uri = this._wv().get_uri();
                    if (!uri || uri.startsWith('file://')) {
                        this._termPrint('Sin página cargada.');
                    } else {
                        try {
                            const host = new URL(uri).hostname;
                            const resolver = Gio.Resolver.get_default();
                            resolver.lookup_by_name_async(host, null, (r, result) => {
                                try {
                                    const addrs = r.lookup_by_name_finish(result);
                                    const ip = addrs[0].to_string();
                                    GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                                        this._termPrint(`${host} → ${ip}`);
                                        this._termPrint(''); this._termPrompt();
                                        return false;
                                    });
                                } catch (e2) {
                                    GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                                        this._termPrint(`Error: ${e2.message}`);
                                        this._termPrint(''); this._termPrompt();
                                        return false;
                                    });
                                }
                            });
                            return;
                        } catch (e) {
                            this._termPrint(`Error: ${e.message}`);
                        }
                    }
                }
                break;
            }

            case 'bookmark': {
                const wv  = this._wv();
                const uri = wv.get_uri();
                if (!uri || uri === 'about:blank') { this._termPrint('Sin página activa.'); break; }
                const title = wv.get_title() || uri;
                if (this._app.isBookmarked(uri)) {
                    this._app.removeBookmark(uri);
                    this._termPrint(`Marcador eliminado: ${uri}`);
                    this._bookmarkStar.set_label('☆');
                } else {
                    this._app.addBookmark(uri, title);
                    this._termPrint(`Marcador guardado: ${title}`);
                    this._bookmarkStar.set_label('★');
                }
                break;
            }

            case 'bookmarks':
                if (!this._app.bookmarks.length) { this._termPrint('Sin marcadores guardados.'); break; }
                this._termPrint('Marcadores guardados:');
                this._app.bookmarks.forEach((b, i) =>
                    this._termPrint(`  ${String(i + 1).padStart(3)}. ${b.title}\n       ${b.url}`)
                );
                break;

            case 'history': {
                const n = parseInt(args, 10) || 10;
                const hist = this._app.history;
                if (!hist.length) { this._termPrint('El historial está vacío.'); break; }
                this._termPrint(`Últimas ${n} páginas:`);
                [...hist].slice(-n).reverse().forEach((h, i) => {
                    const ts = (h.ts || '').slice(0, 19).replace('T', ' ');
                    this._termPrint(`  ${String(i + 1).padStart(3)}. [${ts}] ${h.title}\n       ${h.url}`);
                });
                break;
            }

            case 'dark':
                this._app.darkMode = !this._app.darkMode;
                this._termPrint(`Modo oscuro ${this._app.darkMode ? 'activado' : 'desactivado'}.`);
                if (this._app.darkMode) GLib.idle_add(GLib.PRIORITY_DEFAULT, () => { this._applyDarkCss(); return false; });
                break;

            case 'calc':
                if (args) this._termPrint(`${args} = ${this._safeEval(args)}`);
                else this._termPrint('Uso: calc <expresión>');
                break;

            case 'time':
                this._termPrint(new Date().toTimeString().slice(0, 8));
                break;

            case 'date':
                this._termPrint(new Date().toISOString().slice(0, 10));
                break;

            case 'echo':
                if (args) this._termPrint(args);
                break;

            case 'clear': case 'clean':
                this._terminalBuf.set_text('', -1);
                break;

            case 'about':
                this._termPrint(
                    'PrekT-BR v2.1 — Hardened Edition\n' +
                    'WebKitGTK 6 + GTK 4 + GJS\n' +
                    'Redes: Tor (SOCKS5 :9050), I2P (HTTP :4444)\n' +
                    '─── Protecciones activas ──────────────────────\n' +
                    '  [*] WebRTC, popups, autoplay bloqueados\n' +
                    '  [*] User-Agent: Firefox/Windows normalizado\n' +
                    '  [*] Letterboxing, timing, canvas, audio\n' +
                    '  [*] Navigator, Screen, WebGL normalizados\n' +
                    '  [*] Historial/marcadores: cifrados en disco\n'
                );
                break;

            case 'clearcookies':
                this._clearTabData(this._td());
                this._termPrint('Cookies y datos de sesión de la pestaña actual eliminados.');
                break;

            case 'clearall':
                for (const td of this._tabs) this._clearTabData(td);
                this._termPrint('Datos de todas las pestañas eliminados.');
                break;

            case 'quit': case 'exit':
                this._app.quit();
                return;

            default:
                this._termPrint(`Comando desconocido: '${cmd}'  —  escribe 'help'`);
            }

            this._termPrint('');
            this._termPrompt();
        }

        // ── Calculadora segura ────────────────────────────────────────────────

        _safeEval(expr) {
            // Evaluador AST-safe: solo operaciones matemáticas básicas
            const clean = expr.trim().replace(/\^/g, '**');
            if (!/^[\d\s+\-*/().%,a-z_]+$/i.test(clean))
                return 'Error: expresión no permitida';
            const mathFns = ['abs','acos','asin','atan','atan2','ceil','cos','exp',
                             'floor','hypot','log','log2','log10','max','min','pow',
                             'round','sign','sin','sqrt','tan','trunc','PI','E'];
            const scope = {};
            for (const fn of mathFns) scope[fn] = Math[fn];
            try {
                // Verificar que no hay palabras que no sean funciones math
                const names = clean.match(/[a-zA-Z_][a-zA-Z0-9_]*/g) || [];
                for (const name of names) {
                    if (!mathFns.includes(name))
                        return `Error: nombre no permitido '${name}'`;
                }
                // eslint-disable-next-line no-new-func
                const fn = new Function(...Object.keys(scope), `"use strict"; return (${clean});`);
                const result = fn(...Object.values(scope));
                return String(result);
            } catch (e) {
                return `Error: ${e.message}`;
            }
        }
    }
);

// ─── Punto de entrada ──────────────────────────────────────────────────────

// Necesario para usar GObject.registerClass
import GObject from 'gi://GObject';

const app = new PrekTBRApp();
app.run(ARGV);
